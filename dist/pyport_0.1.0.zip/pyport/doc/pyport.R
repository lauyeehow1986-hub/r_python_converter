## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(pyport)
library(pyrt)

mod <- eval_python("
import itertools

def chunked_sums(items, size):
    out = []
    it = iter(items)
    while True:
        batch = list(itertools.islice(it, size))
        if not batch:
            break
        out.append(sum(batch))
    return out
")

res <- mod$chunked_sums(py_list(as.list(1:10)), 3L)
res$as_r_list()

## -----------------------------------------------------------------------------
py_file <- tempfile(fileext = ".py")
writeLines(c(
  "def moving_average(xs, window=3):",
  "    out = []",
  "    for i in range(len(xs) - window + 1):",
  "        out.append(sum(xs[i:i+window]) / window)",
  "    return out"
), py_file)

pkg_dir <- file.path(tempdir(), "movingavg")
info <- convert(py_file, pkg_dir, pkg_name = "movingavg")
info$exports
unlink(c(py_file, pkg_dir), recursive = TRUE)

