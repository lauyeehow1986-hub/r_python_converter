test_that("test_standard_scaler", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 2.0)), pyrt::py_list(list(3.0, 4.0)), pyrt::py_list(list(5.0, 6.0))))
  scaler <- StandardScaler()
  pyrt::py_getattr(scaler, "fit")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getattr(scaler, "mean_"), 0L), 3.0)), 1e-05)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getattr(scaler, "mean_"), 1L), 4.0)), 1e-05)))
  Xt <- pyrt::py_getattr(scaler, "transform")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(Xt, 1L), 0L), 0.0)), 1e-05)))
  inv <- pyrt::py_getattr(scaler, "inverse_transform")(Xt)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(inv, 0L), 0L), 1.0)), 1e-05)))
})

test_that("test_minmax_scaler", {
  X <- pyrt::py_list(list(pyrt::py_list(list(0.0, 10.0)), pyrt::py_list(list(5.0, 20.0)), pyrt::py_list(list(10.0, 30.0))))
  scaler <- MinMaxScaler()
  Xt <- pyrt::py_getattr(scaler, "fit_transform")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(Xt, 0L), 0L), 0.0)), 1e-05)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(Xt, 2L), 0L), 1.0)), 1e-05)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(Xt, 1L), 1L), 0.5)), 1e-05)))
})

test_that("test_linear_regression", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 2.0)), pyrt::py_list(list(2.0, 1.0)), pyrt::py_list(list(3.0, 4.0)), pyrt::py_list(list(4.0, 3.0)), pyrt::py_list(list(5.0, 5.0))))
  y <- (function() {
    .py_comp_1 <- list()
    .py_it_2 <- pyrt::py_iter(X)
    repeat {
      .py_step_3 <- pyrt::py_iter_step(.py_it_2)
      if (.py_step_3$stopped) break
      r <- .py_step_3$value
      .py_comp_1[length(.py_comp_1) + 1L] <- list(pyrt::py_add(pyrt::py_add(pyrt::py_mul(2L, pyrt::py_getitem(r, 0L)), pyrt::py_mul(3L, pyrt::py_getitem(r, 1L))), 5L))
    }
    pyrt::py_list(.py_comp_1)
  })()
  reg <- LinearRegression()
  pyrt::py_getattr(reg, "fit")(X, y)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getattr(reg, "intercept_"), 5.0)), 0.001)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getattr(reg, "coef_"), 0L), 2.0)), 0.001)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getattr(reg, "coef_"), 1L), 3.0)), 0.001)))
  r2 <- pyrt::py_getattr(reg, "score")(X, y)
  testthat::expect_true(pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pyrt::py_sub(r2, 1.0)), 1e-04)))
})

test_that("test_ridge_regression", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 2.0)), pyrt::py_list(list(2.0, 1.0)), pyrt::py_list(list(3.0, 4.0)), pyrt::py_list(list(4.0, 3.0))))
  y <- pyrt::py_list(list(10.0, 12.0, 18.0, 20.0))
  ridge <- Ridge(alpha = 0.5)
  pyrt::py_getattr(ridge, "fit")(X, y)
  preds <- pyrt::py_getattr(ridge, "predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("len")(preds), 4L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_gt(r2_score(y, preds), 0.9)))
})

test_that("test_logistic_regression", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 1.0)), pyrt::py_list(list(1.5, 1.2)), pyrt::py_list(list(5.0, 5.0)), pyrt::py_list(list(5.5, 6.0))))
  y <- pyrt::py_list(list(0L, 0L, 1L, 1L))
  clf <- LogisticRegression(max_iter = 300L)
  pyrt::py_getattr(clf, "fit")(X, y)
  preds <- pyrt::py_getattr(clf, "predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, 0L), 0L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, 1L), 0L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, 2L), 1L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, 3L), 1L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getattr(clf, "score")(X, y), 1.0)))
})

test_that("test_kmeans_clustering", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 1.0)), pyrt::py_list(list(1.2, 1.1)), pyrt::py_list(list(10.0, 10.0)), pyrt::py_list(list(10.2, 9.8))))
  km <- KMeans(n_clusters = 2L)
  labels <- pyrt::py_getattr(km, "fit_predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(labels, 0L), pyrt::py_getitem(labels, 1L))))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(labels, 2L), pyrt::py_getitem(labels, 3L))))
  testthat::expect_true(pyrt::py_bool(pyrt::py_ne(pyrt::py_getitem(labels, 0L), pyrt::py_getitem(labels, 2L))))
})

test_that("test_knn_classifier", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 1.0)), pyrt::py_list(list(1.5, 1.2)), pyrt::py_list(list(8.0, 8.0)), pyrt::py_list(list(8.5, 8.2))))
  y <- pyrt::py_list(list(0L, 0L, 1L, 1L))
  knn <- KNeighborsClassifier(n_neighbors = 1L)
  pyrt::py_getattr(knn, "fit")(X, y)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(pyrt::py_getattr(knn, "predict")(pyrt::py_list(list(pyrt::py_list(list(1.2, 1.1))))), 0L), 0L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(pyrt::py_getattr(knn, "predict")(pyrt::py_list(list(pyrt::py_list(list(8.2, 8.1))))), 0L), 1L)))
})

test_that("test_decision_tree", {
  X <- pyrt::py_list(list(pyrt::py_list(list(2.0, 3.0)), pyrt::py_list(list(1.0, 1.0)), pyrt::py_list(list(8.0, 7.0)), pyrt::py_list(list(9.0, 8.0))))
  y <- pyrt::py_list(list(0L, 0L, 1L, 1L))
  dt <- DecisionTreeClassifier(max_depth = 3L)
  pyrt::py_getattr(dt, "fit")(X, y)
  preds <- pyrt::py_getattr(dt, "predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("list")(preds), pyrt::py_builtin("list")(y))))
})

test_that("test_gaussian_nb", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 2.0)), pyrt::py_list(list(1.2, 1.8)), pyrt::py_list(list(6.0, 7.0)), pyrt::py_list(list(6.2, 6.8))))
  y <- pyrt::py_list(list(0L, 0L, 1L, 1L))
  gnb <- GaussianNB()
  pyrt::py_getattr(gnb, "fit")(X, y)
  preds <- pyrt::py_getattr(gnb, "predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("list")(preds), pyrt::py_builtin("list")(y))))
})

test_that("test_pca", {
  X <- pyrt::py_list(list(pyrt::py_list(list(1.0, 2.0, 3.0)), pyrt::py_list(list(2.0, 4.0, 6.0)), pyrt::py_list(list(3.0, 6.0, 9.0)), pyrt::py_list(list(4.0, 8.0, 12.0))))
  pca <- PCA(n_components = 1L)
  Xt <- pyrt::py_getattr(pca, "fit_transform")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("len")(Xt), 4L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("len")(pyrt::py_getitem(Xt, 0L)), 1L)))
  testthat::expect_true(pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(pyrt::py_getattr(pca, "explained_variance_ratio_"), 0L), 0.95)))
})

test_that("test_pipeline", {
  X <- pyrt::py_list(list(pyrt::py_list(list(10.0, 20.0)), pyrt::py_list(list(20.0, 10.0)), pyrt::py_list(list(80.0, 90.0)), pyrt::py_list(list(90.0, 80.0))))
  y <- pyrt::py_list(list(0L, 0L, 1L, 1L))
  pipe <- Pipeline(pyrt::py_list(list(pyrt::py_tuple(list("scaler", StandardScaler())), pyrt::py_tuple(list("clf", LogisticRegression(max_iter = 300L))))))
  pyrt::py_getattr(pipe, "fit")(X, y)
  preds <- pyrt::py_getattr(pipe, "predict")(X)
  testthat::expect_true(pyrt::py_bool(pyrt::py_eq(pyrt::py_builtin("list")(preds), pyrt::py_builtin("list")(y))))
})
