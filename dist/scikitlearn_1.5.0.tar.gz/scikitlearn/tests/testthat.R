library(testthat)
library(scikitlearn)

test_check("scikitlearn")
