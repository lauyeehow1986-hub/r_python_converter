# Transpiled from Python module: sklearn/metrics.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
accuracy_score <- function(y_true, y_pred) {
  n <- pyrt::py_builtin("len")(y_true)
  if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
    return(0.0)
  }
  correct <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_1", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
      .py_forloop_2 <- function(.py_sent = NULL) {
        .py_forstep_3 <- pyrt::py_iter_step(.py_forit_1)
        if (.py_forstep_3$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_3$value, envir = .py_gen_env)
        if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(y_true, i), pyrt::py_getitem(y_pred, i)))) {
          pyrt::py_yield(1L, cont = .py_forloop_2)
        } else {
          pyrt::py_bounce(.py_forloop_2)
        }
      }
      pyrt::py_bounce(.py_forloop_2)
    })
  })())
  return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(n)))
}
confusion_matrix <- function(y_true, y_pred) {
  labels <- pyrt::py_builtin("sorted")(pyrt::py_builtin("list")(pyrt::py_builtin("set")(pyrt::py_add(pyrt::py_builtin("list")(y_true), pyrt::py_builtin("list")(y_pred)))))
  label_to_idx <- (function() {
    .py_comp_4 <- pyrt::py_dict()
    .py_it_5 <- pyrt::py_iter(pyrt::py_builtin("enumerate")(labels))
    repeat {
      .py_step_6 <- pyrt::py_iter_step(.py_it_5)
      if (.py_step_6$stopped) break
      .py_unp_7 <- pyrt::py_unpack(.py_step_6$value, 2L)
      i <- .py_unp_7[[1L]]
      l <- .py_unp_7[[2L]]
      .py_comp_4$set(l, i)
    }
    .py_comp_4
  })()
  k <- pyrt::py_builtin("len")(labels)
  cm <- (function() {
    .py_comp_8 <- list()
    .py_it_9 <- pyrt::py_iter(pyrt::py_builtin("range")(k))
    repeat {
      .py_step_10 <- pyrt::py_iter_step(.py_it_9)
      if (.py_step_10$stopped) break
      `_` <- .py_step_10$value
      .py_comp_8[length(.py_comp_8) + 1L] <- list(pyrt::py_mul(pyrt::py_list(list(0L)), k))
    }
    pyrt::py_list(.py_comp_8)
  })()
  for (i in pyrt::py_range_seq(pyrt::py_builtin("len")(y_true))) {
    ti <- pyrt::py_getitem(label_to_idx, pyrt::py_getitem(y_true, i))
    pi <- pyrt::py_getitem(label_to_idx, pyrt::py_getitem(y_pred, i))
    pyrt::py_setitem(pyrt::py_getitem(cm, ti), pi, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(cm, ti), pi), 1L))
  }
  return(cm)
}
precision_score <- function(y_true, y_pred, pos_label = 1L) {
  tp <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_11", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y_true))), envir = .py_gen_env)
      .py_forloop_12 <- function(.py_sent = NULL) {
        .py_forstep_13 <- pyrt::py_iter_step(.py_forit_11)
        if (.py_forstep_13$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_13$value, envir = .py_gen_env)
        if (pyrt::py_bool(({ .py_bool_14 <- pyrt::py_eq(pyrt::py_getitem(y_true, i), pos_label); if (!pyrt::py_bool(.py_bool_14)) .py_bool_14 else pyrt::py_eq(pyrt::py_getitem(y_pred, i), pos_label) }))) {
          pyrt::py_yield(1L, cont = .py_forloop_12)
        } else {
          pyrt::py_bounce(.py_forloop_12)
        }
      }
      pyrt::py_bounce(.py_forloop_12)
    })
  })())
  fp <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_15", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y_true))), envir = .py_gen_env)
      .py_forloop_16 <- function(.py_sent = NULL) {
        .py_forstep_17 <- pyrt::py_iter_step(.py_forit_15)
        if (.py_forstep_17$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_17$value, envir = .py_gen_env)
        if (pyrt::py_bool(({ .py_bool_18 <- pyrt::py_ne(pyrt::py_getitem(y_true, i), pos_label); if (!pyrt::py_bool(.py_bool_18)) .py_bool_18 else pyrt::py_eq(pyrt::py_getitem(y_pred, i), pos_label) }))) {
          pyrt::py_yield(1L, cont = .py_forloop_16)
        } else {
          pyrt::py_bounce(.py_forloop_16)
        }
      }
      pyrt::py_bounce(.py_forloop_16)
    })
  })())
  denom <- pyrt::py_add(tp, fp)
  return((if (pyrt::py_bool(pyrt::py_gt(denom, 0L))) pyrt::py_truediv(pyrt::py_builtin("float")(tp), pyrt::py_builtin("float")(denom)) else 0.0))
}
recall_score <- function(y_true, y_pred, pos_label = 1L) {
  tp <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_19", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y_true))), envir = .py_gen_env)
      .py_forloop_20 <- function(.py_sent = NULL) {
        .py_forstep_21 <- pyrt::py_iter_step(.py_forit_19)
        if (.py_forstep_21$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_21$value, envir = .py_gen_env)
        if (pyrt::py_bool(({ .py_bool_22 <- pyrt::py_eq(pyrt::py_getitem(y_true, i), pos_label); if (!pyrt::py_bool(.py_bool_22)) .py_bool_22 else pyrt::py_eq(pyrt::py_getitem(y_pred, i), pos_label) }))) {
          pyrt::py_yield(1L, cont = .py_forloop_20)
        } else {
          pyrt::py_bounce(.py_forloop_20)
        }
      }
      pyrt::py_bounce(.py_forloop_20)
    })
  })())
  fn <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_23", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y_true))), envir = .py_gen_env)
      .py_forloop_24 <- function(.py_sent = NULL) {
        .py_forstep_25 <- pyrt::py_iter_step(.py_forit_23)
        if (.py_forstep_25$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_25$value, envir = .py_gen_env)
        if (pyrt::py_bool(({ .py_bool_26 <- pyrt::py_eq(pyrt::py_getitem(y_true, i), pos_label); if (!pyrt::py_bool(.py_bool_26)) .py_bool_26 else pyrt::py_ne(pyrt::py_getitem(y_pred, i), pos_label) }))) {
          pyrt::py_yield(1L, cont = .py_forloop_24)
        } else {
          pyrt::py_bounce(.py_forloop_24)
        }
      }
      pyrt::py_bounce(.py_forloop_24)
    })
  })())
  denom <- pyrt::py_add(tp, fn)
  return((if (pyrt::py_bool(pyrt::py_gt(denom, 0L))) pyrt::py_truediv(pyrt::py_builtin("float")(tp), pyrt::py_builtin("float")(denom)) else 0.0))
}
f1_score <- function(y_true, y_pred, pos_label = 1L) {
  p <- precision_score(y_true, y_pred, pos_label = pos_label)
  r <- recall_score(y_true, y_pred, pos_label = pos_label)
  denom <- pyrt::py_add(p, r)
  return((if (pyrt::py_bool(pyrt::py_gt(denom, 0L))) pyrt::py_truediv(pyrt::py_mul(2.0, pyrt::py_mul(p, r)), denom) else 0.0))
}
roc_auc_score <- function(y_true, y_score) {
  pairs <- pyrt::py_builtin("sorted")(pyrt::py_builtin("zip")(y_score, y_true), key = function(x) pyrt::py_getitem(x, 0L))
  n <- pyrt::py_builtin("len")(pairs)
  pos_count <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_27", pyrt::py_iter(pairs), envir = .py_gen_env)
      .py_forloop_28 <- function(.py_sent = NULL) {
        .py_forstep_29 <- pyrt::py_iter_step(.py_forit_27)
        if (.py_forstep_29$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        .py_unp_30 <- pyrt::py_unpack(.py_forstep_29$value, 2L)
        assign("_", .py_unp_30[[1L]], envir = .py_gen_env)
        assign("y", .py_unp_30[[2L]], envir = .py_gen_env)
        if (pyrt::py_bool(pyrt::py_eq(y, 1L))) {
          pyrt::py_yield(1L, cont = .py_forloop_28)
        } else {
          pyrt::py_bounce(.py_forloop_28)
        }
      }
      pyrt::py_bounce(.py_forloop_28)
    })
  })())
  neg_count <- pyrt::py_sub(n, pos_count)
  if (pyrt::py_bool(({ .py_bool_31 <- pyrt::py_eq(pos_count, 0L); if (pyrt::py_bool(.py_bool_31)) .py_bool_31 else pyrt::py_eq(neg_count, 0L) }))) {
    return(0.5)
  }
  rank_sum <- 0L
  .py_it_32 <- pyrt::py_iter(pyrt::py_builtin("enumerate")(pairs, start = 1L))
  repeat {
    .py_step_33 <- pyrt::py_iter_step(.py_it_32)
    if (.py_step_33$stopped) break
    .py_unp_34 <- pyrt::py_unpack(.py_step_33$value, 2L)
    rank <- .py_unp_34[[1L]]
    .py_unp_35 <- pyrt::py_unpack(.py_unp_34[[2L]], 2L)
    `_` <- .py_unp_35[[1L]]
    y <- .py_unp_35[[2L]]
    if (pyrt::py_bool(pyrt::py_eq(y, 1L))) {
      rank_sum <- pyrt::py_add(rank_sum, rank)
    }
  }
  u <- pyrt::py_sub(rank_sum, pyrt::py_truediv(pyrt::py_mul(pos_count, pyrt::py_add(pos_count, 1L)), 2.0))
  return(pyrt::py_truediv(u, pyrt::py_builtin("float")(pyrt::py_mul(pos_count, neg_count))))
}
mean_squared_error <- function(y_true, y_pred) {
  n <- pyrt::py_builtin("len")(y_true)
  if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
    return(0.0)
  }
  s <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_36", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
      .py_forloop_37 <- function(.py_sent = NULL) {
        .py_forstep_38 <- pyrt::py_iter_step(.py_forit_36)
        if (.py_forstep_38$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_38$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y_true, i)), pyrt::py_builtin("float")(pyrt::py_getitem(y_pred, i))), 2L), cont = .py_forloop_37)
      }
      pyrt::py_bounce(.py_forloop_37)
    })
  })())
  return(pyrt::py_truediv(s, pyrt::py_builtin("float")(n)))
}
mean_absolute_error <- function(y_true, y_pred) {
  n <- pyrt::py_builtin("len")(y_true)
  if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
    return(0.0)
  }
  s <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_39", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
      .py_forloop_40 <- function(.py_sent = NULL) {
        .py_forstep_41 <- pyrt::py_iter_step(.py_forit_39)
        if (.py_forstep_41$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_41$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y_true, i)), pyrt::py_builtin("float")(pyrt::py_getitem(y_pred, i)))), cont = .py_forloop_40)
      }
      pyrt::py_bounce(.py_forloop_40)
    })
  })())
  return(pyrt::py_truediv(s, pyrt::py_builtin("float")(n)))
}
r2_score <- function(y_true, y_pred) {
  n <- pyrt::py_builtin("len")(y_true)
  if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
    return(1.0)
  }
  y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_42", pyrt::py_iter(y_true), envir = .py_gen_env)
      .py_forloop_43 <- function(.py_sent = NULL) {
        .py_forstep_44 <- pyrt::py_iter_step(.py_forit_42)
        if (.py_forstep_44$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("yi", .py_forstep_44$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_builtin("float")(yi), cont = .py_forloop_43)
      }
      pyrt::py_bounce(.py_forloop_43)
    })
  })()), pyrt::py_builtin("float")(n))
  ss_tot <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_45", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
      .py_forloop_46 <- function(.py_sent = NULL) {
        .py_forstep_47 <- pyrt::py_iter_step(.py_forit_45)
        if (.py_forstep_47$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_47$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y_true, i)), y_mean), 2L), cont = .py_forloop_46)
      }
      pyrt::py_bounce(.py_forloop_46)
    })
  })())
  ss_res <- pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_48", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
      .py_forloop_49 <- function(.py_sent = NULL) {
        .py_forstep_50 <- pyrt::py_iter_step(.py_forit_48)
        if (.py_forstep_50$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_50$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y_true, i)), pyrt::py_builtin("float")(pyrt::py_getitem(y_pred, i))), 2L), cont = .py_forloop_49)
      }
      pyrt::py_bounce(.py_forloop_49)
    })
  })())
  if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
    return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
  }
  return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
}
