# Transpiled from Python module: sklearn/neighbors.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
`_dist_sq` <- function(p1, p2) {
  s <- 0.0
  for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(p1))) {
    d <- pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(p1, j)), pyrt::py_builtin("float")(pyrt::py_getitem(p2, j)))
    s <- pyrt::py_add(s, pyrt::py_mul(d, d))
  }
  return(s)
}
KNeighborsClassifier <- pyrt::py_class("KNeighborsClassifier", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, n_neighbors = 3L) {
    pyrt::py_setattr(self, "n_neighbors", pyrt::py_builtin("int")(n_neighbors))
    pyrt::py_setattr(self, "X_train_", pyrt::py_list())
    pyrt::py_setattr(self, "y_train_", pyrt::py_list())
    pyrt::py_setattr(self, "classes_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_1[["fit"]] <- function(self, X, y) {
    pyrt::py_setattr(self, "X_train_", (function() {
      .py_comp_2 <- list()
      .py_it_6 <- pyrt::py_iter(X)
      repeat {
        .py_step_7 <- pyrt::py_iter_step(.py_it_6)
        if (.py_step_7$stopped) break
        row <- .py_step_7$value
        .py_comp_2[length(.py_comp_2) + 1L] <- list((function() {
          .py_comp_3 <- list()
          .py_it_4 <- pyrt::py_iter(row)
          repeat {
            .py_step_5 <- pyrt::py_iter_step(.py_it_4)
            if (.py_step_5$stopped) break
            v <- .py_step_5$value
            .py_comp_3[length(.py_comp_3) + 1L] <- list(pyrt::py_builtin("float")(v))
          }
          pyrt::py_list(.py_comp_3)
        })())
      }
      pyrt::py_list(.py_comp_2)
    })())
    pyrt::py_setattr(self, "y_train_", (function() {
      .py_comp_8 <- list()
      .py_it_9 <- pyrt::py_iter(y)
      repeat {
        .py_step_10 <- pyrt::py_iter_step(.py_it_9)
        if (.py_step_10$stopped) break
        v <- .py_step_10$value
        .py_comp_8[length(.py_comp_8) + 1L] <- list(pyrt::py_builtin("int")(v))
      }
      pyrt::py_list(.py_comp_8)
    })())
    unique <- pyrt::py_list()
    .py_it_11 <- pyrt::py_iter(pyrt::py_getattr(self, "y_train_"))
    repeat {
      .py_step_12 <- pyrt::py_iter_step(.py_it_11)
      if (.py_step_12$stopped) break
      lab <- .py_step_12$value
      if (pyrt::py_bool((!pyrt::py_in(lab, unique)))) {
        pyrt::py_getattr(unique, "append")(lab)
      }
    }
    pyrt::py_getattr(unique, "sort")()
    pyrt::py_setattr(self, "classes_", unique)
    return(self)
  }
  .py_cdict_1[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    k <- pyrt::py_builtin("min")(pyrt::py_getattr(self, "n_neighbors"), pyrt::py_builtin("len")(pyrt::py_getattr(self, "X_train_")))
    .py_it_13 <- pyrt::py_iter(X)
    repeat {
      .py_step_14 <- pyrt::py_iter_step(.py_it_13)
      if (.py_step_14$stopped) break
      row <- .py_step_14$value
      dists <- pyrt::py_list()
      for (i in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "X_train_")))) {
        pyrt::py_getattr(dists, "append")(pyrt::py_tuple(list(`_dist_sq`(row, pyrt::py_getitem(pyrt::py_getattr(self, "X_train_"), i)), pyrt::py_getitem(pyrt::py_getattr(self, "y_train_"), i))))
      }
      pyrt::py_getattr(dists, "sort")(key = function(t) pyrt::py_getitem(t, 0L))
      top_k <- pyrt::py_getitem(dists, pyrt::py_slice(NULL, k, NULL))
      votes <- pyrt::py_dict()
      .py_it_15 <- pyrt::py_iter(top_k)
      repeat {
        .py_step_16 <- pyrt::py_iter_step(.py_it_15)
        if (.py_step_16$stopped) break
        .py_unp_17 <- pyrt::py_unpack(.py_step_16$value, 2L)
        `_` <- .py_unp_17[[1L]]
        lab <- .py_unp_17[[2L]]
        pyrt::py_setitem(votes, lab, pyrt::py_add(pyrt::py_getattr(votes, "get")(lab, 0L), 1L))
      }
      best_lab <- pyrt::py_builtin("max")(pyrt::py_getattr(votes, "keys")(), key = function(l) pyrt::py_getitem(votes, l))
      pyrt::py_getattr(preds, "append")(best_lab)
    }
    return(preds)
  }
  .py_cdict_1[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    correct <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_18", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y))), envir = .py_gen_env)
        .py_forloop_19 <- function(.py_sent = NULL) {
          .py_forstep_20 <- pyrt::py_iter_step(.py_forit_18)
          if (.py_forstep_20$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_20$value, envir = .py_gen_env)
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, i), pyrt::py_builtin("int")(pyrt::py_getitem(y, i))))) {
            pyrt::py_yield(1L, cont = .py_forloop_19)
          } else {
            pyrt::py_bounce(.py_forloop_19)
          }
        }
        pyrt::py_bounce(.py_forloop_19)
      })
    })())
    return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(pyrt::py_builtin("len")(y))))
  }
  .py_cdict_1
})())
KNeighborsRegressor <- pyrt::py_class("KNeighborsRegressor", bases = list(), dict = (function() {
  .py_cdict_21 <- list()
  .py_cdict_21[["__init__"]] <- function(self, n_neighbors = 3L) {
    pyrt::py_setattr(self, "n_neighbors", pyrt::py_builtin("int")(n_neighbors))
    pyrt::py_setattr(self, "X_train_", pyrt::py_list())
    pyrt::py_setattr(self, "y_train_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_21[["fit"]] <- function(self, X, y) {
    pyrt::py_setattr(self, "X_train_", (function() {
      .py_comp_22 <- list()
      .py_it_26 <- pyrt::py_iter(X)
      repeat {
        .py_step_27 <- pyrt::py_iter_step(.py_it_26)
        if (.py_step_27$stopped) break
        row <- .py_step_27$value
        .py_comp_22[length(.py_comp_22) + 1L] <- list((function() {
          .py_comp_23 <- list()
          .py_it_24 <- pyrt::py_iter(row)
          repeat {
            .py_step_25 <- pyrt::py_iter_step(.py_it_24)
            if (.py_step_25$stopped) break
            v <- .py_step_25$value
            .py_comp_23[length(.py_comp_23) + 1L] <- list(pyrt::py_builtin("float")(v))
          }
          pyrt::py_list(.py_comp_23)
        })())
      }
      pyrt::py_list(.py_comp_22)
    })())
    pyrt::py_setattr(self, "y_train_", (function() {
      .py_comp_28 <- list()
      .py_it_29 <- pyrt::py_iter(y)
      repeat {
        .py_step_30 <- pyrt::py_iter_step(.py_it_29)
        if (.py_step_30$stopped) break
        v <- .py_step_30$value
        .py_comp_28[length(.py_comp_28) + 1L] <- list(pyrt::py_builtin("float")(v))
      }
      pyrt::py_list(.py_comp_28)
    })())
    return(self)
  }
  .py_cdict_21[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    k <- pyrt::py_builtin("min")(pyrt::py_getattr(self, "n_neighbors"), pyrt::py_builtin("len")(pyrt::py_getattr(self, "X_train_")))
    .py_it_31 <- pyrt::py_iter(X)
    repeat {
      .py_step_32 <- pyrt::py_iter_step(.py_it_31)
      if (.py_step_32$stopped) break
      row <- .py_step_32$value
      dists <- pyrt::py_list()
      for (i in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "X_train_")))) {
        pyrt::py_getattr(dists, "append")(pyrt::py_tuple(list(`_dist_sq`(row, pyrt::py_getitem(pyrt::py_getattr(self, "X_train_"), i)), pyrt::py_getitem(pyrt::py_getattr(self, "y_train_"), i))))
      }
      pyrt::py_getattr(dists, "sort")(key = function(t) pyrt::py_getitem(t, 0L))
      top_k <- pyrt::py_getitem(dists, pyrt::py_slice(NULL, k, NULL))
      avg <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
        .py_gen_env <- environment()
        pyrt::py_generator(function(.py_sent = NULL) {
          assign(".py_forit_33", pyrt::py_iter(top_k), envir = .py_gen_env)
          .py_forloop_34 <- function(.py_sent = NULL) {
            .py_forstep_35 <- pyrt::py_iter_step(.py_forit_33)
            if (.py_forstep_35$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
            .py_unp_36 <- pyrt::py_unpack(.py_forstep_35$value, 2L)
            assign("_", .py_unp_36[[1L]], envir = .py_gen_env)
            assign("val", .py_unp_36[[2L]], envir = .py_gen_env)
            pyrt::py_yield(val, cont = .py_forloop_34)
          }
          pyrt::py_bounce(.py_forloop_34)
        })
      })()), pyrt::py_builtin("float")(k))
      pyrt::py_getattr(preds, "append")(avg)
    }
    return(preds)
  }
  .py_cdict_21[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(1.0)
    }
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_37", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_38 <- function(.py_sent = NULL) {
          .py_forstep_39 <- pyrt::py_iter_step(.py_forit_37)
          if (.py_forstep_39$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("yi", .py_forstep_39$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_builtin("float")(yi), cont = .py_forloop_38)
        }
        pyrt::py_bounce(.py_forloop_38)
      })
    })()), pyrt::py_builtin("float")(n))
    ss_tot <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_40", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_41 <- function(.py_sent = NULL) {
          .py_forstep_42 <- pyrt::py_iter_step(.py_forit_40)
          if (.py_forstep_42$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_42$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), y_mean), 2L), cont = .py_forloop_41)
        }
        pyrt::py_bounce(.py_forloop_41)
      })
    })())
    ss_res <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_43", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_44 <- function(.py_sent = NULL) {
          .py_forstep_45 <- pyrt::py_iter_step(.py_forit_43)
          if (.py_forstep_45$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_45$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), pyrt::py_getitem(preds, i)), 2L), cont = .py_forloop_44)
        }
        pyrt::py_bounce(.py_forloop_44)
      })
    })())
    if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
      return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
    }
    return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
  }
  .py_cdict_21
})())
