# Transpiled from Python module: sklearn/naive_bayes.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
math <- pyrt::py_stdlib("math")
GaussianNB <- pyrt::py_class("GaussianNB", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, var_smoothing = 1e-09) {
    pyrt::py_setattr(self, "var_smoothing", pyrt::py_builtin("float")(var_smoothing))
    pyrt::py_setattr(self, "classes_", pyrt::py_list())
    pyrt::py_setattr(self, "class_priors_", pyrt::py_list())
    pyrt::py_setattr(self, "theta_", pyrt::py_list())
    pyrt::py_setattr(self, "var_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_1[["fit"]] <- function(self, X, y) {
    n <- pyrt::py_builtin("len")(X)
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    y_int <- (function() {
      .py_comp_2 <- list()
      .py_it_3 <- pyrt::py_iter(y)
      repeat {
        .py_step_4 <- pyrt::py_iter_step(.py_it_3)
        if (.py_step_4$stopped) break
        v <- .py_step_4$value
        .py_comp_2[length(.py_comp_2) + 1L] <- list(pyrt::py_builtin("int")(v))
      }
      pyrt::py_list(.py_comp_2)
    })()
    classes <- pyrt::py_builtin("sorted")(pyrt::py_builtin("list")(pyrt::py_builtin("set")(y_int)))
    pyrt::py_setattr(self, "classes_", classes)
    n_classes <- pyrt::py_builtin("len")(classes)
    priors <- pyrt::py_list()
    thetas <- pyrt::py_list()
    vars_ <- pyrt::py_list()
    .py_it_5 <- pyrt::py_iter(classes)
    repeat {
      .py_step_6 <- pyrt::py_iter_step(.py_it_5)
      if (.py_step_6$stopped) break
      c <- .py_step_6$value
      c_indices <- (function() {
        .py_comp_7 <- list()
        .py_it_8 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
        repeat {
          .py_step_9 <- pyrt::py_iter_step(.py_it_8)
          if (.py_step_9$stopped) break
          i <- .py_step_9$value
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(y_int, i), c))) {
            .py_comp_7[length(.py_comp_7) + 1L] <- list(i)
          }
        }
        pyrt::py_list(.py_comp_7)
      })()
      n_c <- pyrt::py_builtin("len")(c_indices)
      pyrt::py_getattr(priors, "append")(pyrt::py_truediv(pyrt::py_builtin("float")(n_c), pyrt::py_builtin("float")(n)))
      means <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
      .py_it_10 <- pyrt::py_iter(c_indices)
      repeat {
        .py_step_11 <- pyrt::py_iter_step(.py_it_10)
        if (.py_step_11$stopped) break
        i <- .py_step_11$value
        for (j in pyrt::py_range_seq(p)) {
          pyrt::py_setitem(means, j, pyrt::py_add(pyrt::py_getitem(means, j), pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j))))
        }
      }
      for (j in pyrt::py_range_seq(p)) {
        pyrt::py_setitem(means, j, pyrt::py_truediv(pyrt::py_getitem(means, j), pyrt::py_builtin("float")(n_c)))
      }
      variances <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
      .py_it_12 <- pyrt::py_iter(c_indices)
      repeat {
        .py_step_13 <- pyrt::py_iter_step(.py_it_12)
        if (.py_step_13$stopped) break
        i <- .py_step_13$value
        for (j in pyrt::py_range_seq(p)) {
          diff <- pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j)), pyrt::py_getitem(means, j))
          pyrt::py_setitem(variances, j, pyrt::py_add(pyrt::py_getitem(variances, j), pyrt::py_mul(diff, diff)))
        }
      }
      for (j in pyrt::py_range_seq(p)) {
        pyrt::py_setitem(variances, j, pyrt::py_add(pyrt::py_truediv(pyrt::py_getitem(variances, j), pyrt::py_builtin("float")(n_c)), pyrt::py_getattr(self, "var_smoothing")))
      }
      pyrt::py_getattr(thetas, "append")(means)
      pyrt::py_getattr(vars_, "append")(variances)
    }
    pyrt::py_setattr(self, "class_priors_", priors)
    pyrt::py_setattr(self, "theta_", thetas)
    pyrt::py_setattr(self, "var_", vars_)
    return(self)
  }
  .py_cdict_1[["_log_gaussian_prob"]] <- function(self, x_val, mean, var) {
    log_norm <- pyrt::py_mul(pyrt::py_neg(0.5), pyrt::py_getattr(math, "log")(pyrt::py_mul(pyrt::py_mul(2.0, pyrt::py_getattr(math, "pi")), var)))
    sq_diff <- pyrt::py_pow(pyrt::py_sub(x_val, mean), 2L)
    return(pyrt::py_sub(log_norm, pyrt::py_truediv(sq_diff, pyrt::py_mul(2.0, var))))
  }
  .py_cdict_1[["predict_log_proba"]] <- function(self, X) {
    log_probs <- pyrt::py_list()
    n_classes <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "classes_"))
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(pyrt::py_getattr(self, "theta_"), 0L))
    .py_it_14 <- pyrt::py_iter(X)
    repeat {
      .py_step_15 <- pyrt::py_iter_step(.py_it_14)
      if (.py_step_15$stopped) break
      row <- .py_step_15$value
      row_lps <- pyrt::py_list()
      for (c_idx in pyrt::py_range_seq(n_classes)) {
        lp <- pyrt::py_getattr(math, "log")(pyrt::py_add(pyrt::py_getitem(pyrt::py_getattr(self, "class_priors_"), c_idx), 1e-15))
        for (j in pyrt::py_range_seq(p)) {
          lp <- pyrt::py_add(lp, pyrt::py_getattr(self, "_log_gaussian_prob")(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), pyrt::py_getitem(pyrt::py_getitem(pyrt::py_getattr(self, "theta_"), c_idx), j), pyrt::py_getitem(pyrt::py_getitem(pyrt::py_getattr(self, "var_"), c_idx), j)))
        }
        pyrt::py_getattr(row_lps, "append")(lp)
      }
      pyrt::py_getattr(log_probs, "append")(row_lps)
    }
    return(log_probs)
  }
  .py_cdict_1[["predict"]] <- function(self, X) {
    lps <- pyrt::py_getattr(self, "predict_log_proba")(X)
    preds <- pyrt::py_list()
    .py_it_16 <- pyrt::py_iter(lps)
    repeat {
      .py_step_17 <- pyrt::py_iter_step(.py_it_16)
      if (.py_step_17$stopped) break
      row <- .py_step_17$value
      best_c <- 0L
      best_val <- pyrt::py_getitem(row, 0L)
      for (c_idx in pyrt::py_range_seq(1L, pyrt::py_builtin("len")(row))) {
        if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(row, c_idx), best_val))) {
          best_val <- pyrt::py_getitem(row, c_idx)
          best_c <- c_idx
        }
      }
      pyrt::py_getattr(preds, "append")(pyrt::py_getitem(pyrt::py_getattr(self, "classes_"), best_c))
    }
    return(preds)
  }
  .py_cdict_1[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    correct <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_18", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y))), envir = .py_gen_env)
        .py_forloop_19 <- function(.py_sent = NULL) {
          .py_forstep_20 <- pyrt::py_iter_step(.py_forit_18)
          if (.py_forstep_20$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_20$value, envir = .py_gen_env)
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, i), pyrt::py_builtin("int")(pyrt::py_getitem(y, i))))) {
            pyrt::py_yield(1L, cont = .py_forloop_19)
          } else {
            pyrt::py_bounce(.py_forloop_19)
          }
        }
        pyrt::py_bounce(.py_forloop_19)
      })
    })())
    return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(pyrt::py_builtin("len")(y))))
  }
  .py_cdict_1
})())
