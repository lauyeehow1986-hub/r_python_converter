# Transpiled from Python module: sklearn/base.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
BaseEstimator <- pyrt::py_class("BaseEstimator", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self) {
    invisible(NULL)
    pyrt::py_none()
  }
  .py_cdict_1[["get_params"]] <- function(self) {
    return(pyrt::py_dict())
  }
  .py_cdict_1[["set_params"]] <- function(self, ...) {
    .py_va_2 <- pyrt::py_split_varargs(list(...), vararg = FALSE, kwarg = TRUE)
    params <- .py_va_2$kwargs
    return(self)
  }
  .py_cdict_1
})())
ClassifierMixin <- pyrt::py_class("ClassifierMixin", bases = list(), dict = (function() {
  .py_cdict_3 <- list()
  .py_cdict_3[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    correct <- 0L
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
      return(0.0)
    }
    for (i in pyrt::py_range_seq(n)) {
      if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, i), pyrt::py_getitem(y, i)))) {
        correct <- pyrt::py_add(correct, 1L)
      }
    }
    return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(n)))
  }
  .py_cdict_3
})())
RegressorMixin <- pyrt::py_class("RegressorMixin", bases = list(), dict = (function() {
  .py_cdict_4 <- list()
  .py_cdict_4[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(1.0)
    }
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")(y), pyrt::py_builtin("float")(n))
    ss_tot <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_5", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_6 <- function(.py_sent = NULL) {
          .py_forstep_7 <- pyrt::py_iter_step(.py_forit_5)
          if (.py_forstep_7$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_7$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_getitem(y, i), y_mean), 2L), cont = .py_forloop_6)
        }
        pyrt::py_bounce(.py_forloop_6)
      })
    })())
    ss_res <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_8", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_9 <- function(.py_sent = NULL) {
          .py_forstep_10 <- pyrt::py_iter_step(.py_forit_8)
          if (.py_forstep_10$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_10$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_getitem(y, i), pyrt::py_getitem(preds, i)), 2L), cont = .py_forloop_9)
        }
        pyrt::py_bounce(.py_forloop_9)
      })
    })())
    if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
      return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
    }
    return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
  }
  .py_cdict_4
})())
TransformerMixin <- pyrt::py_class("TransformerMixin", bases = list(), dict = (function() {
  .py_cdict_11 <- list()
  .py_cdict_11[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "transform")(X))
  }
  .py_cdict_11
})())
