# Transpiled from Python module: sklearn/model_selection.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
train_test_split <- function(X, y, test_size = 0.25, shuffle = TRUE, random_state = pyrt::py_none()) {
  n <- pyrt::py_builtin("len")(X)
  n_test <- pyrt::py_builtin("max")(1L, pyrt::py_builtin("int")(pyrt::py_mul(n, pyrt::py_builtin("float")(test_size))))
  indices <- pyrt::py_builtin("list")(pyrt::py_builtin("range")(n))
  if (pyrt::py_bool(shuffle)) {
    seed <- (if (pyrt::py_bool(pyrt::py_is(random_state, pyrt::py_none()))) 42L else pyrt::py_builtin("int")(random_state))
    for (i in pyrt::py_range_seq(pyrt::py_sub(n, 1L), 0L, pyrt::py_neg(1L))) {
      seed <- pyrt::py_bitand(pyrt::py_add(pyrt::py_mul(seed, 1103515245L), 12345L), 2147483647L)
      j <- pyrt::py_mod(seed, pyrt::py_add(i, 1L))
      .py_unp_1 <- pyrt::py_unpack(pyrt::py_tuple(list(pyrt::py_getitem(indices, j), pyrt::py_getitem(indices, i))), 2L)
      pyrt::py_setitem(indices, i, .py_unp_1[[1L]])
      pyrt::py_setitem(indices, j, .py_unp_1[[2L]])
    }
  }
  test_idx <- pyrt::py_getitem(indices, pyrt::py_slice(NULL, n_test, NULL))
  train_idx <- pyrt::py_getitem(indices, pyrt::py_slice(n_test, NULL, NULL))
  X_train <- (function() {
    .py_comp_2 <- list()
    .py_it_3 <- pyrt::py_iter(train_idx)
    repeat {
      .py_step_4 <- pyrt::py_iter_step(.py_it_3)
      if (.py_step_4$stopped) break
      i <- .py_step_4$value
      .py_comp_2[length(.py_comp_2) + 1L] <- list(pyrt::py_getitem(X, i))
    }
    pyrt::py_list(.py_comp_2)
  })()
  X_test <- (function() {
    .py_comp_5 <- list()
    .py_it_6 <- pyrt::py_iter(test_idx)
    repeat {
      .py_step_7 <- pyrt::py_iter_step(.py_it_6)
      if (.py_step_7$stopped) break
      i <- .py_step_7$value
      .py_comp_5[length(.py_comp_5) + 1L] <- list(pyrt::py_getitem(X, i))
    }
    pyrt::py_list(.py_comp_5)
  })()
  y_train <- (function() {
    .py_comp_8 <- list()
    .py_it_9 <- pyrt::py_iter(train_idx)
    repeat {
      .py_step_10 <- pyrt::py_iter_step(.py_it_9)
      if (.py_step_10$stopped) break
      i <- .py_step_10$value
      .py_comp_8[length(.py_comp_8) + 1L] <- list(pyrt::py_getitem(y, i))
    }
    pyrt::py_list(.py_comp_8)
  })()
  y_test <- (function() {
    .py_comp_11 <- list()
    .py_it_12 <- pyrt::py_iter(test_idx)
    repeat {
      .py_step_13 <- pyrt::py_iter_step(.py_it_12)
      if (.py_step_13$stopped) break
      i <- .py_step_13$value
      .py_comp_11[length(.py_comp_11) + 1L] <- list(pyrt::py_getitem(y, i))
    }
    pyrt::py_list(.py_comp_11)
  })()
  return(pyrt::py_tuple(list(X_train, X_test, y_train, y_test)))
}
KFold <- pyrt::py_class("KFold", bases = list(), dict = (function() {
  .py_cdict_14 <- list()
  .py_cdict_14[["__init__"]] <- function(self, n_splits = 5L, shuffle = FALSE, random_state = pyrt::py_none()) {
    pyrt::py_setattr(self, "n_splits", pyrt::py_builtin("int")(n_splits))
    pyrt::py_setattr(self, "shuffle", shuffle)
    pyrt::py_setattr(self, "random_state", random_state)
    pyrt::py_none()
  }
  .py_cdict_14[["split"]] <- function(self, X) {
    n <- pyrt::py_builtin("len")(X)
    indices <- pyrt::py_builtin("list")(pyrt::py_builtin("range")(n))
    if (pyrt::py_bool(pyrt::py_getattr(self, "shuffle"))) {
      seed <- (if (pyrt::py_bool(pyrt::py_is(pyrt::py_getattr(self, "random_state"), pyrt::py_none()))) 42L else pyrt::py_builtin("int")(pyrt::py_getattr(self, "random_state")))
      for (i in pyrt::py_range_seq(pyrt::py_sub(n, 1L), 0L, pyrt::py_neg(1L))) {
        seed <- pyrt::py_bitand(pyrt::py_add(pyrt::py_mul(seed, 1103515245L), 12345L), 2147483647L)
        j <- pyrt::py_mod(seed, pyrt::py_add(i, 1L))
        .py_unp_15 <- pyrt::py_unpack(pyrt::py_tuple(list(pyrt::py_getitem(indices, j), pyrt::py_getitem(indices, i))), 2L)
        pyrt::py_setitem(indices, i, .py_unp_15[[1L]])
        pyrt::py_setitem(indices, j, .py_unp_15[[2L]])
      }
    }
    fold_sizes <- pyrt::py_mul(pyrt::py_list(list(pyrt::py_floordiv(n, pyrt::py_getattr(self, "n_splits")))), pyrt::py_getattr(self, "n_splits"))
    for (i in pyrt::py_range_seq(pyrt::py_mod(n, pyrt::py_getattr(self, "n_splits")))) {
      pyrt::py_setitem(fold_sizes, i, pyrt::py_add(pyrt::py_getitem(fold_sizes, i), 1L))
    }
    splits <- pyrt::py_list()
    current <- 0L
    .py_it_16 <- pyrt::py_iter(fold_sizes)
    repeat {
      .py_step_17 <- pyrt::py_iter_step(.py_it_16)
      if (.py_step_17$stopped) break
      fold_size <- .py_step_17$value
      test_indices <- pyrt::py_getitem(indices, pyrt::py_slice(current, pyrt::py_add(current, fold_size), NULL))
      train_indices <- pyrt::py_add(pyrt::py_getitem(indices, pyrt::py_slice(NULL, current, NULL)), pyrt::py_getitem(indices, pyrt::py_slice(pyrt::py_add(current, fold_size), NULL, NULL)))
      pyrt::py_getattr(splits, "append")(pyrt::py_tuple(list(train_indices, test_indices)))
      current <- pyrt::py_add(current, fold_size)
    }
    return(splits)
  }
  .py_cdict_14
})())
