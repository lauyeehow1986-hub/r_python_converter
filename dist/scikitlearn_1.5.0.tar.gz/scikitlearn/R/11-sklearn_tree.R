# Transpiled from Python module: sklearn/tree.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
`_TreeNode` <- pyrt::py_class("_TreeNode", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, feature = pyrt::py_none(), threshold = pyrt::py_none(), left = pyrt::py_none(), right = pyrt::py_none(), value = pyrt::py_none()) {
    pyrt::py_setattr(self, "feature", feature)
    pyrt::py_setattr(self, "threshold", threshold)
    pyrt::py_setattr(self, "left", left)
    pyrt::py_setattr(self, "right", right)
    pyrt::py_setattr(self, "value", value)
    pyrt::py_none()
  }
  .py_cdict_1
})())
`_gini` <- function(y) {
  n <- pyrt::py_builtin("len")(y)
  if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
    return(0.0)
  }
  counts <- pyrt::py_dict()
  .py_it_2 <- pyrt::py_iter(y)
  repeat {
    .py_step_3 <- pyrt::py_iter_step(.py_it_2)
    if (.py_step_3$stopped) break
    lab <- .py_step_3$value
    pyrt::py_setitem(counts, lab, pyrt::py_add(pyrt::py_getattr(counts, "get")(lab, 0L), 1L))
  }
  impurity <- 1.0
  .py_it_4 <- pyrt::py_iter(pyrt::py_getattr(counts, "values")())
  repeat {
    .py_step_5 <- pyrt::py_iter_step(.py_it_4)
    if (.py_step_5$stopped) break
    c <- .py_step_5$value
    p <- pyrt::py_truediv(c, pyrt::py_builtin("float")(n))
    impurity <- pyrt::py_sub(impurity, pyrt::py_mul(p, p))
  }
  return(impurity)
}
DecisionTreeClassifier <- pyrt::py_class("DecisionTreeClassifier", bases = list(), dict = (function() {
  .py_cdict_6 <- list()
  .py_cdict_6[["__init__"]] <- function(self, max_depth = 5L, min_samples_split = 2L) {
    pyrt::py_setattr(self, "max_depth", pyrt::py_builtin("int")(max_depth))
    pyrt::py_setattr(self, "min_samples_split", pyrt::py_builtin("int")(min_samples_split))
    pyrt::py_setattr(self, "root_", pyrt::py_none())
    pyrt::py_none()
  }
  .py_cdict_6[["_majority_vote"]] <- function(self, y) {
    counts <- pyrt::py_dict()
    .py_it_7 <- pyrt::py_iter(y)
    repeat {
      .py_step_8 <- pyrt::py_iter_step(.py_it_7)
      if (.py_step_8$stopped) break
      lab <- .py_step_8$value
      pyrt::py_setitem(counts, lab, pyrt::py_add(pyrt::py_getattr(counts, "get")(lab, 0L), 1L))
    }
    return(pyrt::py_builtin("max")(pyrt::py_getattr(counts, "keys")(), key = function(l) pyrt::py_getitem(counts, l)))
  }
  .py_cdict_6[["_build_tree"]] <- function(self, X, y, depth = 0L) {
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
      return(pyrt::py_none())
    }
    majority <- pyrt::py_getattr(self, "_majority_vote")(y)
    if (pyrt::py_bool(({ .py_bool_10 <- pyrt::py_ge(depth, pyrt::py_getattr(self, "max_depth")); if (pyrt::py_bool(.py_bool_10)) .py_bool_10 else { .py_bool_9 <- pyrt::py_lt(n, pyrt::py_getattr(self, "min_samples_split")); if (pyrt::py_bool(.py_bool_9)) .py_bool_9 else pyrt::py_eq(`_gini`(y), 0.0) } }))) {
      return(`_TreeNode`(value = majority))
    }
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    best_gain <- 0.0
    best_feat <- pyrt::py_none()
    best_thresh <- pyrt::py_none()
    current_gini <- `_gini`(y)
    for (feat in pyrt::py_range_seq(p)) {
      vals <- pyrt::py_builtin("sorted")(pyrt::py_builtin("list")(pyrt::py_builtin("set")((function() {
        .py_gen_env <- environment()
        pyrt::py_generator(function(.py_sent = NULL) {
          assign(".py_forit_11", pyrt::py_iter(X), envir = .py_gen_env)
          .py_forloop_12 <- function(.py_sent = NULL) {
            .py_forstep_13 <- pyrt::py_iter_step(.py_forit_11)
            if (.py_forstep_13$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
            assign("row", .py_forstep_13$value, envir = .py_gen_env)
            pyrt::py_yield(pyrt::py_getitem(row, feat), cont = .py_forloop_12)
          }
          pyrt::py_bounce(.py_forloop_12)
        })
      })())))
      for (k in pyrt::py_range_seq(pyrt::py_sub(pyrt::py_builtin("len")(vals), 1L))) {
        thresh <- pyrt::py_truediv(pyrt::py_add(pyrt::py_getitem(vals, k), pyrt::py_getitem(vals, pyrt::py_add(k, 1L))), 2.0)
        left_y <- (function() {
          .py_comp_14 <- list()
          .py_it_15 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
          repeat {
            .py_step_16 <- pyrt::py_iter_step(.py_it_15)
            if (.py_step_16$stopped) break
            i <- .py_step_16$value
            if (pyrt::py_bool(pyrt::py_le(pyrt::py_getitem(pyrt::py_getitem(X, i), feat), thresh))) {
              .py_comp_14[length(.py_comp_14) + 1L] <- list(pyrt::py_getitem(y, i))
            }
          }
          pyrt::py_list(.py_comp_14)
        })()
        right_y <- (function() {
          .py_comp_17 <- list()
          .py_it_18 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
          repeat {
            .py_step_19 <- pyrt::py_iter_step(.py_it_18)
            if (.py_step_19$stopped) break
            i <- .py_step_19$value
            if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(pyrt::py_getitem(X, i), feat), thresh))) {
              .py_comp_17[length(.py_comp_17) + 1L] <- list(pyrt::py_getitem(y, i))
            }
          }
          pyrt::py_list(.py_comp_17)
        })()
        if (pyrt::py_bool(({ .py_bool_20 <- pyrt::py_eq(pyrt::py_builtin("len")(left_y), 0L); if (pyrt::py_bool(.py_bool_20)) .py_bool_20 else pyrt::py_eq(pyrt::py_builtin("len")(right_y), 0L) }))) {
          next
        }
        gain <- pyrt::py_sub(current_gini, pyrt::py_add(pyrt::py_mul(pyrt::py_truediv(pyrt::py_builtin("len")(left_y), pyrt::py_builtin("float")(n)), `_gini`(left_y)), pyrt::py_mul(pyrt::py_truediv(pyrt::py_builtin("len")(right_y), pyrt::py_builtin("float")(n)), `_gini`(right_y))))
        if (pyrt::py_bool(pyrt::py_gt(gain, best_gain))) {
          best_gain <- gain
          best_feat <- feat
          best_thresh <- thresh
        }
      }
    }
    if (pyrt::py_bool(pyrt::py_lt(best_gain, 1e-07))) {
      return(`_TreeNode`(value = majority))
    }
    left_idx <- (function() {
      .py_comp_21 <- list()
      .py_it_22 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_23 <- pyrt::py_iter_step(.py_it_22)
        if (.py_step_23$stopped) break
        i <- .py_step_23$value
        if (pyrt::py_bool(pyrt::py_le(pyrt::py_getitem(pyrt::py_getitem(X, i), best_feat), best_thresh))) {
          .py_comp_21[length(.py_comp_21) + 1L] <- list(i)
        }
      }
      pyrt::py_list(.py_comp_21)
    })()
    right_idx <- (function() {
      .py_comp_24 <- list()
      .py_it_25 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_26 <- pyrt::py_iter_step(.py_it_25)
        if (.py_step_26$stopped) break
        i <- .py_step_26$value
        if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(pyrt::py_getitem(X, i), best_feat), best_thresh))) {
          .py_comp_24[length(.py_comp_24) + 1L] <- list(i)
        }
      }
      pyrt::py_list(.py_comp_24)
    })()
    left_child <- pyrt::py_getattr(self, "_build_tree")((function() {
      .py_comp_27 <- list()
      .py_it_28 <- pyrt::py_iter(left_idx)
      repeat {
        .py_step_29 <- pyrt::py_iter_step(.py_it_28)
        if (.py_step_29$stopped) break
        i <- .py_step_29$value
        .py_comp_27[length(.py_comp_27) + 1L] <- list(pyrt::py_getitem(X, i))
      }
      pyrt::py_list(.py_comp_27)
    })(), (function() {
      .py_comp_30 <- list()
      .py_it_31 <- pyrt::py_iter(left_idx)
      repeat {
        .py_step_32 <- pyrt::py_iter_step(.py_it_31)
        if (.py_step_32$stopped) break
        i <- .py_step_32$value
        .py_comp_30[length(.py_comp_30) + 1L] <- list(pyrt::py_getitem(y, i))
      }
      pyrt::py_list(.py_comp_30)
    })(), pyrt::py_add(depth, 1L))
    right_child <- pyrt::py_getattr(self, "_build_tree")((function() {
      .py_comp_33 <- list()
      .py_it_34 <- pyrt::py_iter(right_idx)
      repeat {
        .py_step_35 <- pyrt::py_iter_step(.py_it_34)
        if (.py_step_35$stopped) break
        i <- .py_step_35$value
        .py_comp_33[length(.py_comp_33) + 1L] <- list(pyrt::py_getitem(X, i))
      }
      pyrt::py_list(.py_comp_33)
    })(), (function() {
      .py_comp_36 <- list()
      .py_it_37 <- pyrt::py_iter(right_idx)
      repeat {
        .py_step_38 <- pyrt::py_iter_step(.py_it_37)
        if (.py_step_38$stopped) break
        i <- .py_step_38$value
        .py_comp_36[length(.py_comp_36) + 1L] <- list(pyrt::py_getitem(y, i))
      }
      pyrt::py_list(.py_comp_36)
    })(), pyrt::py_add(depth, 1L))
    return(`_TreeNode`(feature = best_feat, threshold = best_thresh, left = left_child, right = right_child, value = majority))
  }
  .py_cdict_6[["fit"]] <- function(self, X, y) {
    X_float <- (function() {
      .py_comp_39 <- list()
      .py_it_43 <- pyrt::py_iter(X)
      repeat {
        .py_step_44 <- pyrt::py_iter_step(.py_it_43)
        if (.py_step_44$stopped) break
        row <- .py_step_44$value
        .py_comp_39[length(.py_comp_39) + 1L] <- list((function() {
          .py_comp_40 <- list()
          .py_it_41 <- pyrt::py_iter(row)
          repeat {
            .py_step_42 <- pyrt::py_iter_step(.py_it_41)
            if (.py_step_42$stopped) break
            v <- .py_step_42$value
            .py_comp_40[length(.py_comp_40) + 1L] <- list(pyrt::py_builtin("float")(v))
          }
          pyrt::py_list(.py_comp_40)
        })())
      }
      pyrt::py_list(.py_comp_39)
    })()
    y_int <- (function() {
      .py_comp_45 <- list()
      .py_it_46 <- pyrt::py_iter(y)
      repeat {
        .py_step_47 <- pyrt::py_iter_step(.py_it_46)
        if (.py_step_47$stopped) break
        v <- .py_step_47$value
        .py_comp_45[length(.py_comp_45) + 1L] <- list(pyrt::py_builtin("int")(v))
      }
      pyrt::py_list(.py_comp_45)
    })()
    pyrt::py_setattr(self, "root_", pyrt::py_getattr(self, "_build_tree")(X_float, y_int, depth = 0L))
    return(self)
  }
  .py_cdict_6[["_predict_row"]] <- function(self, row, node) {
    if (pyrt::py_bool(({ .py_bool_48 <- pyrt::py_is(pyrt::py_getattr(node, "left"), pyrt::py_none()); if (!pyrt::py_bool(.py_bool_48)) .py_bool_48 else pyrt::py_is(pyrt::py_getattr(node, "right"), pyrt::py_none()) }))) {
      return(pyrt::py_getattr(node, "value"))
    }
    if (pyrt::py_bool(({ .py_bool_49 <- (!pyrt::py_is(pyrt::py_getattr(node, "feature"), pyrt::py_none())); if (!pyrt::py_bool(.py_bool_49)) .py_bool_49 else pyrt::py_le(pyrt::py_getitem(row, pyrt::py_getattr(node, "feature")), pyrt::py_getattr(node, "threshold")) }))) {
      return((if (pyrt::py_bool(pyrt::py_getattr(node, "left"))) pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(node, "left")) else pyrt::py_getattr(node, "value")))
    } else {
      return((if (pyrt::py_bool(pyrt::py_getattr(node, "right"))) pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(node, "right")) else pyrt::py_getattr(node, "value")))
    }
    pyrt::py_none()
  }
  .py_cdict_6[["predict"]] <- function(self, X) {
    return((function() {
      .py_comp_50 <- list()
      .py_it_51 <- pyrt::py_iter(X)
      repeat {
        .py_step_52 <- pyrt::py_iter_step(.py_it_51)
        if (.py_step_52$stopped) break
        row <- .py_step_52$value
        .py_comp_50[length(.py_comp_50) + 1L] <- list(pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(self, "root_")))
      }
      pyrt::py_list(.py_comp_50)
    })())
  }
  .py_cdict_6[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    correct <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_53", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y))), envir = .py_gen_env)
        .py_forloop_54 <- function(.py_sent = NULL) {
          .py_forstep_55 <- pyrt::py_iter_step(.py_forit_53)
          if (.py_forstep_55$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_55$value, envir = .py_gen_env)
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, i), pyrt::py_builtin("int")(pyrt::py_getitem(y, i))))) {
            pyrt::py_yield(1L, cont = .py_forloop_54)
          } else {
            pyrt::py_bounce(.py_forloop_54)
          }
        }
        pyrt::py_bounce(.py_forloop_54)
      })
    })())
    return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(pyrt::py_builtin("len")(y))))
  }
  .py_cdict_6
})())
DecisionTreeRegressor <- pyrt::py_class("DecisionTreeRegressor", bases = list(), dict = (function() {
  .py_cdict_56 <- list()
  .py_cdict_56[["__init__"]] <- function(self, max_depth = 5L, min_samples_split = 2L) {
    pyrt::py_setattr(self, "max_depth", pyrt::py_builtin("int")(max_depth))
    pyrt::py_setattr(self, "min_samples_split", pyrt::py_builtin("int")(min_samples_split))
    pyrt::py_setattr(self, "root_", pyrt::py_none())
    pyrt::py_none()
  }
  .py_cdict_56[["_mean_val"]] <- function(self, y) {
    return((if (pyrt::py_bool(pyrt::py_gt(pyrt::py_builtin("len")(y), 0L))) pyrt::py_truediv(pyrt::py_builtin("sum")(y), pyrt::py_builtin("float")(pyrt::py_builtin("len")(y))) else 0.0))
  }
  .py_cdict_56[["_mse"]] <- function(self, y) {
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(0.0)
    }
    m <- pyrt::py_getattr(self, "_mean_val")(y)
    return(pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_57", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_58 <- function(.py_sent = NULL) {
          .py_forstep_59 <- pyrt::py_iter_step(.py_forit_57)
          if (.py_forstep_59$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("yi", .py_forstep_59$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(yi, m), 2L), cont = .py_forloop_58)
        }
        pyrt::py_bounce(.py_forloop_58)
      })
    })()), pyrt::py_builtin("float")(n)))
  }
  .py_cdict_56[["_build_tree"]] <- function(self, X, y, depth = 0L) {
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_eq(n, 0L))) {
      return(pyrt::py_none())
    }
    mean_y <- pyrt::py_getattr(self, "_mean_val")(y)
    if (pyrt::py_bool(({ .py_bool_60 <- pyrt::py_ge(depth, pyrt::py_getattr(self, "max_depth")); if (pyrt::py_bool(.py_bool_60)) .py_bool_60 else pyrt::py_lt(n, pyrt::py_getattr(self, "min_samples_split")) }))) {
      return(`_TreeNode`(value = mean_y))
    }
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    best_gain <- 0.0
    best_feat <- pyrt::py_none()
    best_thresh <- pyrt::py_none()
    current_mse <- pyrt::py_getattr(self, "_mse")(y)
    for (feat in pyrt::py_range_seq(p)) {
      vals <- pyrt::py_builtin("sorted")(pyrt::py_builtin("list")(pyrt::py_builtin("set")((function() {
        .py_gen_env <- environment()
        pyrt::py_generator(function(.py_sent = NULL) {
          assign(".py_forit_61", pyrt::py_iter(X), envir = .py_gen_env)
          .py_forloop_62 <- function(.py_sent = NULL) {
            .py_forstep_63 <- pyrt::py_iter_step(.py_forit_61)
            if (.py_forstep_63$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
            assign("row", .py_forstep_63$value, envir = .py_gen_env)
            pyrt::py_yield(pyrt::py_getitem(row, feat), cont = .py_forloop_62)
          }
          pyrt::py_bounce(.py_forloop_62)
        })
      })())))
      for (k in pyrt::py_range_seq(pyrt::py_sub(pyrt::py_builtin("len")(vals), 1L))) {
        thresh <- pyrt::py_truediv(pyrt::py_add(pyrt::py_getitem(vals, k), pyrt::py_getitem(vals, pyrt::py_add(k, 1L))), 2.0)
        left_y <- (function() {
          .py_comp_64 <- list()
          .py_it_65 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
          repeat {
            .py_step_66 <- pyrt::py_iter_step(.py_it_65)
            if (.py_step_66$stopped) break
            i <- .py_step_66$value
            if (pyrt::py_bool(pyrt::py_le(pyrt::py_getitem(pyrt::py_getitem(X, i), feat), thresh))) {
              .py_comp_64[length(.py_comp_64) + 1L] <- list(pyrt::py_getitem(y, i))
            }
          }
          pyrt::py_list(.py_comp_64)
        })()
        right_y <- (function() {
          .py_comp_67 <- list()
          .py_it_68 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
          repeat {
            .py_step_69 <- pyrt::py_iter_step(.py_it_68)
            if (.py_step_69$stopped) break
            i <- .py_step_69$value
            if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(pyrt::py_getitem(X, i), feat), thresh))) {
              .py_comp_67[length(.py_comp_67) + 1L] <- list(pyrt::py_getitem(y, i))
            }
          }
          pyrt::py_list(.py_comp_67)
        })()
        if (pyrt::py_bool(({ .py_bool_70 <- pyrt::py_eq(pyrt::py_builtin("len")(left_y), 0L); if (pyrt::py_bool(.py_bool_70)) .py_bool_70 else pyrt::py_eq(pyrt::py_builtin("len")(right_y), 0L) }))) {
          next
        }
        gain <- pyrt::py_sub(current_mse, pyrt::py_add(pyrt::py_mul(pyrt::py_truediv(pyrt::py_builtin("len")(left_y), pyrt::py_builtin("float")(n)), pyrt::py_getattr(self, "_mse")(left_y)), pyrt::py_mul(pyrt::py_truediv(pyrt::py_builtin("len")(right_y), pyrt::py_builtin("float")(n)), pyrt::py_getattr(self, "_mse")(right_y))))
        if (pyrt::py_bool(pyrt::py_gt(gain, best_gain))) {
          best_gain <- gain
          best_feat <- feat
          best_thresh <- thresh
        }
      }
    }
    if (pyrt::py_bool(pyrt::py_lt(best_gain, 1e-07))) {
      return(`_TreeNode`(value = mean_y))
    }
    left_idx <- (function() {
      .py_comp_71 <- list()
      .py_it_72 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_73 <- pyrt::py_iter_step(.py_it_72)
        if (.py_step_73$stopped) break
        i <- .py_step_73$value
        if (pyrt::py_bool(pyrt::py_le(pyrt::py_getitem(pyrt::py_getitem(X, i), best_feat), best_thresh))) {
          .py_comp_71[length(.py_comp_71) + 1L] <- list(i)
        }
      }
      pyrt::py_list(.py_comp_71)
    })()
    right_idx <- (function() {
      .py_comp_74 <- list()
      .py_it_75 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_76 <- pyrt::py_iter_step(.py_it_75)
        if (.py_step_76$stopped) break
        i <- .py_step_76$value
        if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(pyrt::py_getitem(X, i), best_feat), best_thresh))) {
          .py_comp_74[length(.py_comp_74) + 1L] <- list(i)
        }
      }
      pyrt::py_list(.py_comp_74)
    })()
    left_child <- pyrt::py_getattr(self, "_build_tree")((function() {
      .py_comp_77 <- list()
      .py_it_78 <- pyrt::py_iter(left_idx)
      repeat {
        .py_step_79 <- pyrt::py_iter_step(.py_it_78)
        if (.py_step_79$stopped) break
        i <- .py_step_79$value
        .py_comp_77[length(.py_comp_77) + 1L] <- list(pyrt::py_getitem(X, i))
      }
      pyrt::py_list(.py_comp_77)
    })(), (function() {
      .py_comp_80 <- list()
      .py_it_81 <- pyrt::py_iter(left_idx)
      repeat {
        .py_step_82 <- pyrt::py_iter_step(.py_it_81)
        if (.py_step_82$stopped) break
        i <- .py_step_82$value
        .py_comp_80[length(.py_comp_80) + 1L] <- list(pyrt::py_getitem(y, i))
      }
      pyrt::py_list(.py_comp_80)
    })(), pyrt::py_add(depth, 1L))
    right_child <- pyrt::py_getattr(self, "_build_tree")((function() {
      .py_comp_83 <- list()
      .py_it_84 <- pyrt::py_iter(right_idx)
      repeat {
        .py_step_85 <- pyrt::py_iter_step(.py_it_84)
        if (.py_step_85$stopped) break
        i <- .py_step_85$value
        .py_comp_83[length(.py_comp_83) + 1L] <- list(pyrt::py_getitem(X, i))
      }
      pyrt::py_list(.py_comp_83)
    })(), (function() {
      .py_comp_86 <- list()
      .py_it_87 <- pyrt::py_iter(right_idx)
      repeat {
        .py_step_88 <- pyrt::py_iter_step(.py_it_87)
        if (.py_step_88$stopped) break
        i <- .py_step_88$value
        .py_comp_86[length(.py_comp_86) + 1L] <- list(pyrt::py_getitem(y, i))
      }
      pyrt::py_list(.py_comp_86)
    })(), pyrt::py_add(depth, 1L))
    return(`_TreeNode`(feature = best_feat, threshold = best_thresh, left = left_child, right = right_child, value = mean_y))
  }
  .py_cdict_56[["fit"]] <- function(self, X, y) {
    X_float <- (function() {
      .py_comp_89 <- list()
      .py_it_93 <- pyrt::py_iter(X)
      repeat {
        .py_step_94 <- pyrt::py_iter_step(.py_it_93)
        if (.py_step_94$stopped) break
        row <- .py_step_94$value
        .py_comp_89[length(.py_comp_89) + 1L] <- list((function() {
          .py_comp_90 <- list()
          .py_it_91 <- pyrt::py_iter(row)
          repeat {
            .py_step_92 <- pyrt::py_iter_step(.py_it_91)
            if (.py_step_92$stopped) break
            v <- .py_step_92$value
            .py_comp_90[length(.py_comp_90) + 1L] <- list(pyrt::py_builtin("float")(v))
          }
          pyrt::py_list(.py_comp_90)
        })())
      }
      pyrt::py_list(.py_comp_89)
    })()
    y_float <- (function() {
      .py_comp_95 <- list()
      .py_it_96 <- pyrt::py_iter(y)
      repeat {
        .py_step_97 <- pyrt::py_iter_step(.py_it_96)
        if (.py_step_97$stopped) break
        v <- .py_step_97$value
        .py_comp_95[length(.py_comp_95) + 1L] <- list(pyrt::py_builtin("float")(v))
      }
      pyrt::py_list(.py_comp_95)
    })()
    pyrt::py_setattr(self, "root_", pyrt::py_getattr(self, "_build_tree")(X_float, y_float, depth = 0L))
    return(self)
  }
  .py_cdict_56[["_predict_row"]] <- function(self, row, node) {
    if (pyrt::py_bool(({ .py_bool_98 <- pyrt::py_is(pyrt::py_getattr(node, "left"), pyrt::py_none()); if (!pyrt::py_bool(.py_bool_98)) .py_bool_98 else pyrt::py_is(pyrt::py_getattr(node, "right"), pyrt::py_none()) }))) {
      return(pyrt::py_getattr(node, "value"))
    }
    if (pyrt::py_bool(({ .py_bool_99 <- (!pyrt::py_is(pyrt::py_getattr(node, "feature"), pyrt::py_none())); if (!pyrt::py_bool(.py_bool_99)) .py_bool_99 else pyrt::py_le(pyrt::py_getitem(row, pyrt::py_getattr(node, "feature")), pyrt::py_getattr(node, "threshold")) }))) {
      return((if (pyrt::py_bool(pyrt::py_getattr(node, "left"))) pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(node, "left")) else pyrt::py_getattr(node, "value")))
    } else {
      return((if (pyrt::py_bool(pyrt::py_getattr(node, "right"))) pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(node, "right")) else pyrt::py_getattr(node, "value")))
    }
    pyrt::py_none()
  }
  .py_cdict_56[["predict"]] <- function(self, X) {
    return((function() {
      .py_comp_100 <- list()
      .py_it_101 <- pyrt::py_iter(X)
      repeat {
        .py_step_102 <- pyrt::py_iter_step(.py_it_101)
        if (.py_step_102$stopped) break
        row <- .py_step_102$value
        .py_comp_100[length(.py_comp_100) + 1L] <- list(pyrt::py_getattr(self, "_predict_row")(row, pyrt::py_getattr(self, "root_")))
      }
      pyrt::py_list(.py_comp_100)
    })())
  }
  .py_cdict_56[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(1.0)
    }
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_103", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_104 <- function(.py_sent = NULL) {
          .py_forstep_105 <- pyrt::py_iter_step(.py_forit_103)
          if (.py_forstep_105$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("yi", .py_forstep_105$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_builtin("float")(yi), cont = .py_forloop_104)
        }
        pyrt::py_bounce(.py_forloop_104)
      })
    })()), pyrt::py_builtin("float")(n))
    ss_tot <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_106", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_107 <- function(.py_sent = NULL) {
          .py_forstep_108 <- pyrt::py_iter_step(.py_forit_106)
          if (.py_forstep_108$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_108$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), y_mean), 2L), cont = .py_forloop_107)
        }
        pyrt::py_bounce(.py_forloop_107)
      })
    })())
    ss_res <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_109", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_110 <- function(.py_sent = NULL) {
          .py_forstep_111 <- pyrt::py_iter_step(.py_forit_109)
          if (.py_forstep_111$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_111$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), pyrt::py_getitem(preds, i)), 2L), cont = .py_forloop_110)
        }
        pyrt::py_bounce(.py_forloop_110)
      })
    })())
    if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
      return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
    }
    return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
  }
  .py_cdict_56
})())
