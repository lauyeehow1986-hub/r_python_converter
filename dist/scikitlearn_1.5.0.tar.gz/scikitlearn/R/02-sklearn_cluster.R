# Transpiled from Python module: sklearn/cluster.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
math <- pyrt::py_stdlib("math")
`_euclidean_dist_sq` <- function(p1, p2) {
  s <- 0.0
  for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(p1))) {
    d <- pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(p1, j)), pyrt::py_builtin("float")(pyrt::py_getitem(p2, j)))
    s <- pyrt::py_add(s, pyrt::py_mul(d, d))
  }
  return(s)
}
KMeans <- pyrt::py_class("KMeans", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, n_clusters = 2L, max_iter = 100L, tol = 1e-04) {
    pyrt::py_setattr(self, "n_clusters", pyrt::py_builtin("int")(n_clusters))
    pyrt::py_setattr(self, "max_iter", pyrt::py_builtin("int")(max_iter))
    pyrt::py_setattr(self, "tol", pyrt::py_builtin("float")(tol))
    pyrt::py_setattr(self, "cluster_centers_", pyrt::py_list())
    pyrt::py_setattr(self, "labels_", pyrt::py_list())
    pyrt::py_setattr(self, "inertia_", 0.0)
    pyrt::py_none()
  }
  .py_cdict_1[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n_samples <- pyrt::py_builtin("len")(X)
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    k <- pyrt::py_builtin("min")(pyrt::py_getattr(self, "n_clusters"), n_samples)
    step <- pyrt::py_builtin("max")(1L, pyrt::py_floordiv(n_samples, k))
    centers <- (function() {
      .py_comp_2 <- list()
      .py_it_6 <- pyrt::py_iter(pyrt::py_builtin("range")(k))
      repeat {
        .py_step_7 <- pyrt::py_iter_step(.py_it_6)
        if (.py_step_7$stopped) break
        i <- .py_step_7$value
        .py_comp_2[length(.py_comp_2) + 1L] <- list((function() {
          .py_comp_3 <- list()
          .py_it_4 <- pyrt::py_iter(pyrt::py_getitem(X, pyrt::py_builtin("min")(pyrt::py_mul(i, step), pyrt::py_sub(n_samples, 1L))))
          repeat {
            .py_step_5 <- pyrt::py_iter_step(.py_it_4)
            if (.py_step_5$stopped) break
            v <- .py_step_5$value
            .py_comp_3[length(.py_comp_3) + 1L] <- list(pyrt::py_builtin("float")(v))
          }
          pyrt::py_list(.py_comp_3)
        })())
      }
      pyrt::py_list(.py_comp_2)
    })()
    labels <- pyrt::py_mul(pyrt::py_list(list(0L)), n_samples)
    for (`_` in pyrt::py_range_seq(pyrt::py_getattr(self, "max_iter"))) {
      new_labels <- pyrt::py_list()
      .py_it_8 <- pyrt::py_iter(X)
      repeat {
        .py_step_9 <- pyrt::py_iter_step(.py_it_8)
        if (.py_step_9$stopped) break
        row <- .py_step_9$value
        best_k <- 0L
        min_d <- `_euclidean_dist_sq`(row, pyrt::py_getitem(centers, 0L))
        for (c_idx in pyrt::py_range_seq(1L, k)) {
          d <- `_euclidean_dist_sq`(row, pyrt::py_getitem(centers, c_idx))
          if (pyrt::py_bool(pyrt::py_lt(d, min_d))) {
            min_d <- d
            best_k <- c_idx
          }
        }
        pyrt::py_getattr(new_labels, "append")(best_k)
      }
      new_centers <- (function() {
        .py_comp_10 <- list()
        .py_it_11 <- pyrt::py_iter(pyrt::py_builtin("range")(k))
        repeat {
          .py_step_12 <- pyrt::py_iter_step(.py_it_11)
          if (.py_step_12$stopped) break
          `_` <- .py_step_12$value
          .py_comp_10[length(.py_comp_10) + 1L] <- list(pyrt::py_mul(pyrt::py_list(list(0.0)), n_features))
        }
        pyrt::py_list(.py_comp_10)
      })()
      counts <- pyrt::py_mul(pyrt::py_list(list(0L)), k)
      for (i in pyrt::py_range_seq(n_samples)) {
        c_idx <- pyrt::py_getitem(new_labels, i)
        pyrt::py_setitem(counts, c_idx, pyrt::py_add(pyrt::py_getitem(counts, c_idx), 1L))
        for (j in pyrt::py_range_seq(n_features)) {
          pyrt::py_setitem(pyrt::py_getitem(new_centers, c_idx), j, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(new_centers, c_idx), j), pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j))))
        }
      }
      max_shift <- 0.0
      for (c_idx in pyrt::py_range_seq(k)) {
        if (pyrt::py_bool(pyrt::py_gt(pyrt::py_getitem(counts, c_idx), 0L))) {
          for (j in pyrt::py_range_seq(n_features)) {
            pyrt::py_setitem(pyrt::py_getitem(new_centers, c_idx), j, pyrt::py_truediv(pyrt::py_getitem(pyrt::py_getitem(new_centers, c_idx), j), pyrt::py_builtin("float")(pyrt::py_getitem(counts, c_idx))))
            shift <- pyrt::py_builtin("abs")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(new_centers, c_idx), j), pyrt::py_getitem(pyrt::py_getitem(centers, c_idx), j)))
            if (pyrt::py_bool(pyrt::py_gt(shift, max_shift))) {
              max_shift <- shift
            }
          }
        } else {
          pyrt::py_setitem(new_centers, c_idx, pyrt::py_builtin("list")(pyrt::py_getitem(centers, c_idx)))
        }
      }
      centers <- new_centers
      labels <- new_labels
      if (pyrt::py_bool(pyrt::py_lt(max_shift, pyrt::py_getattr(self, "tol")))) {
        break
      }
    }
    inertia <- 0.0
    for (i in pyrt::py_range_seq(n_samples)) {
      inertia <- pyrt::py_add(inertia, `_euclidean_dist_sq`(pyrt::py_getitem(X, i), pyrt::py_getitem(centers, pyrt::py_getitem(labels, i))))
    }
    pyrt::py_setattr(self, "cluster_centers_", centers)
    pyrt::py_setattr(self, "labels_", labels)
    pyrt::py_setattr(self, "inertia_", inertia)
    return(self)
  }
  .py_cdict_1[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    .py_it_13 <- pyrt::py_iter(X)
    repeat {
      .py_step_14 <- pyrt::py_iter_step(.py_it_13)
      if (.py_step_14$stopped) break
      row <- .py_step_14$value
      best_k <- 0L
      min_d <- `_euclidean_dist_sq`(row, pyrt::py_getitem(pyrt::py_getattr(self, "cluster_centers_"), 0L))
      for (c_idx in pyrt::py_range_seq(1L, pyrt::py_builtin("len")(pyrt::py_getattr(self, "cluster_centers_")))) {
        d <- `_euclidean_dist_sq`(row, pyrt::py_getitem(pyrt::py_getattr(self, "cluster_centers_"), c_idx))
        if (pyrt::py_bool(pyrt::py_lt(d, min_d))) {
          min_d <- d
          best_k <- c_idx
        }
      }
      pyrt::py_getattr(preds, "append")(best_k)
    }
    return(preds)
  }
  .py_cdict_1[["fit_predict"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "labels_"))
  }
  .py_cdict_1
})())
DBSCAN <- pyrt::py_class("DBSCAN", bases = list(), dict = (function() {
  .py_cdict_15 <- list()
  .py_cdict_15[["__init__"]] <- function(self, eps = 0.5, min_samples = 5L) {
    pyrt::py_setattr(self, "eps", pyrt::py_builtin("float")(eps))
    pyrt::py_setattr(self, "min_samples", pyrt::py_builtin("int")(min_samples))
    pyrt::py_setattr(self, "labels_", pyrt::py_list())
    pyrt::py_setattr(self, "core_sample_indices_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_15[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n <- pyrt::py_builtin("len")(X)
    eps_sq <- pyrt::py_mul(pyrt::py_getattr(self, "eps"), pyrt::py_getattr(self, "eps"))
    labels <- pyrt::py_mul(pyrt::py_list(list(pyrt::py_neg(1L))), n)
    core_samples <- pyrt::py_list()
    visited <- pyrt::py_mul(pyrt::py_list(list(FALSE)), n)
    neighbors <- pyrt::py_list()
    for (i in pyrt::py_range_seq(n)) {
      nbrs_i <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n)) {
        if (pyrt::py_bool(pyrt::py_le(`_euclidean_dist_sq`(pyrt::py_getitem(X, i), pyrt::py_getitem(X, j)), eps_sq))) {
          pyrt::py_getattr(nbrs_i, "append")(j)
        }
      }
      pyrt::py_getattr(neighbors, "append")(nbrs_i)
      if (pyrt::py_bool(pyrt::py_ge(pyrt::py_builtin("len")(nbrs_i), pyrt::py_getattr(self, "min_samples")))) {
        pyrt::py_getattr(core_samples, "append")(i)
      }
    }
    cluster_id <- 0L
    for (i in pyrt::py_range_seq(n)) {
      if (pyrt::py_bool(pyrt::py_getitem(visited, i))) {
        next
      }
      pyrt::py_setitem(visited, i, TRUE)
      nbrs <- pyrt::py_builtin("list")(pyrt::py_getitem(neighbors, i))
      if (pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("len")(nbrs), pyrt::py_getattr(self, "min_samples")))) {
        pyrt::py_setitem(labels, i, pyrt::py_neg(1L))
      } else {
        pyrt::py_setitem(labels, i, cluster_id)
        k <- 0L
        while (pyrt::py_bool(pyrt::py_lt(k, pyrt::py_builtin("len")(nbrs)))) {
          pt <- pyrt::py_getitem(nbrs, k)
          k <- pyrt::py_add(k, 1L)
          if (pyrt::py_bool((!pyrt::py_bool(pyrt::py_getitem(visited, pt))))) {
            pyrt::py_setitem(visited, pt, TRUE)
            pt_nbrs <- pyrt::py_getitem(neighbors, pt)
            if (pyrt::py_bool(pyrt::py_ge(pyrt::py_builtin("len")(pt_nbrs), pyrt::py_getattr(self, "min_samples")))) {
              .py_it_16 <- pyrt::py_iter(pt_nbrs)
              repeat {
                .py_step_17 <- pyrt::py_iter_step(.py_it_16)
                if (.py_step_17$stopped) break
                p_sub <- .py_step_17$value
                if (pyrt::py_bool((!pyrt::py_in(p_sub, nbrs)))) {
                  pyrt::py_getattr(nbrs, "append")(p_sub)
                }
              }
            }
          }
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(labels, pt), pyrt::py_neg(1L)))) {
            pyrt::py_setitem(labels, pt, cluster_id)
          }
        }
        cluster_id <- pyrt::py_add(cluster_id, 1L)
      }
    }
    pyrt::py_setattr(self, "labels_", labels)
    pyrt::py_setattr(self, "core_sample_indices_", core_samples)
    return(self)
  }
  .py_cdict_15[["fit_predict"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "labels_"))
  }
  .py_cdict_15
})())
