# Transpiled from Python module: sklearn/linear_model.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
math <- pyrt::py_stdlib("math")
`_solve_linear_system` <- function(A, b) {
  n <- pyrt::py_builtin("len")(A)
  M <- pyrt::py_list()
  for (i in pyrt::py_range_seq(n)) {
    pyrt::py_getattr(M, "append")(pyrt::py_add((function() {
      .py_comp_1 <- list()
      .py_it_2 <- pyrt::py_iter(pyrt::py_getitem(A, i))
      repeat {
        .py_step_3 <- pyrt::py_iter_step(.py_it_2)
        if (.py_step_3$stopped) break
        x <- .py_step_3$value
        .py_comp_1[length(.py_comp_1) + 1L] <- list(pyrt::py_builtin("float")(x))
      }
      pyrt::py_list(.py_comp_1)
    })(), pyrt::py_list(list(pyrt::py_builtin("float")(pyrt::py_getitem(b, i))))))
  }
  for (i in pyrt::py_range_seq(n)) {
    max_row <- i
    max_val <- pyrt::py_builtin("abs")(pyrt::py_getitem(pyrt::py_getitem(M, i), i))
    for (k in pyrt::py_range_seq(pyrt::py_add(i, 1L), n)) {
      if (pyrt::py_bool(pyrt::py_gt(pyrt::py_builtin("abs")(pyrt::py_getitem(pyrt::py_getitem(M, k), i)), max_val))) {
        max_val <- pyrt::py_builtin("abs")(pyrt::py_getitem(pyrt::py_getitem(M, k), i))
        max_row <- k
      }
    }
    if (pyrt::py_bool(pyrt::py_ne(max_row, i))) {
      .py_unp_4 <- pyrt::py_unpack(pyrt::py_tuple(list(pyrt::py_getitem(M, max_row), pyrt::py_getitem(M, i))), 2L)
      pyrt::py_setitem(M, i, .py_unp_4[[1L]])
      pyrt::py_setitem(M, max_row, .py_unp_4[[2L]])
    }
    pivot <- pyrt::py_getitem(pyrt::py_getitem(M, i), i)
    if (pyrt::py_bool(pyrt::py_lt(pyrt::py_builtin("abs")(pivot), 1e-12))) {
      pivot <- (if (pyrt::py_bool(pyrt::py_ge(pivot, 0L))) 1e-12 else pyrt::py_neg(1e-12))
    }
    for (j in pyrt::py_range_seq(i, pyrt::py_add(n, 1L))) {
      pyrt::py_setitem(pyrt::py_getitem(M, i), j, pyrt::py_truediv(pyrt::py_getitem(pyrt::py_getitem(M, i), j), pivot))
    }
    for (k in pyrt::py_range_seq(n)) {
      if (pyrt::py_bool(pyrt::py_ne(k, i))) {
        factor <- pyrt::py_getitem(pyrt::py_getitem(M, k), i)
        for (j in pyrt::py_range_seq(i, pyrt::py_add(n, 1L))) {
          pyrt::py_setitem(pyrt::py_getitem(M, k), j, pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(M, k), j), pyrt::py_mul(factor, pyrt::py_getitem(pyrt::py_getitem(M, i), j))))
        }
      }
    }
  }
  return((function() {
    .py_comp_5 <- list()
    .py_it_6 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
    repeat {
      .py_step_7 <- pyrt::py_iter_step(.py_it_6)
      if (.py_step_7$stopped) break
      i <- .py_step_7$value
      .py_comp_5[length(.py_comp_5) + 1L] <- list(pyrt::py_getitem(pyrt::py_getitem(M, i), n))
    }
    pyrt::py_list(.py_comp_5)
  })())
}
LinearRegression <- pyrt::py_class("LinearRegression", bases = list(), dict = (function() {
  .py_cdict_8 <- list()
  .py_cdict_8[["__init__"]] <- function(self, fit_intercept = TRUE) {
    pyrt::py_setattr(self, "fit_intercept", fit_intercept)
    pyrt::py_setattr(self, "coef_", pyrt::py_list())
    pyrt::py_setattr(self, "intercept_", 0.0)
    pyrt::py_none()
  }
  .py_cdict_8[["fit"]] <- function(self, X, y) {
    n_samples <- pyrt::py_builtin("len")(X)
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
      X_aug <- (function() {
        .py_comp_9 <- list()
        .py_it_13 <- pyrt::py_iter(X)
        repeat {
          .py_step_14 <- pyrt::py_iter_step(.py_it_13)
          if (.py_step_14$stopped) break
          row <- .py_step_14$value
          .py_comp_9[length(.py_comp_9) + 1L] <- list(pyrt::py_add(pyrt::py_list(list(1.0)), (function() {
            .py_comp_10 <- list()
            .py_it_11 <- pyrt::py_iter(row)
            repeat {
              .py_step_12 <- pyrt::py_iter_step(.py_it_11)
              if (.py_step_12$stopped) break
              v <- .py_step_12$value
              .py_comp_10[length(.py_comp_10) + 1L] <- list(pyrt::py_builtin("float")(v))
            }
            pyrt::py_list(.py_comp_10)
          })()))
        }
        pyrt::py_list(.py_comp_9)
      })()
      p <- pyrt::py_add(n_features, 1L)
    } else {
      X_aug <- (function() {
        .py_comp_15 <- list()
        .py_it_19 <- pyrt::py_iter(X)
        repeat {
          .py_step_20 <- pyrt::py_iter_step(.py_it_19)
          if (.py_step_20$stopped) break
          row <- .py_step_20$value
          .py_comp_15[length(.py_comp_15) + 1L] <- list((function() {
            .py_comp_16 <- list()
            .py_it_17 <- pyrt::py_iter(row)
            repeat {
              .py_step_18 <- pyrt::py_iter_step(.py_it_17)
              if (.py_step_18$stopped) break
              v <- .py_step_18$value
              .py_comp_16[length(.py_comp_16) + 1L] <- list(pyrt::py_builtin("float")(v))
            }
            pyrt::py_list(.py_comp_16)
          })())
        }
        pyrt::py_list(.py_comp_15)
      })()
      p <- n_features
    }
    XtX <- (function() {
      .py_comp_21 <- list()
      .py_it_22 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_23 <- pyrt::py_iter_step(.py_it_22)
        if (.py_step_23$stopped) break
        `_` <- .py_step_23$value
        .py_comp_21[length(.py_comp_21) + 1L] <- list(pyrt::py_mul(pyrt::py_list(list(0.0)), p))
      }
      pyrt::py_list(.py_comp_21)
    })()
    Xty <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
    for (i in pyrt::py_range_seq(n_samples)) {
      row <- pyrt::py_getitem(X_aug, i)
      yi <- pyrt::py_builtin("float")(pyrt::py_getitem(y, i))
      for (j in pyrt::py_range_seq(p)) {
        rj <- pyrt::py_getitem(row, j)
        pyrt::py_setitem(Xty, j, pyrt::py_add(pyrt::py_getitem(Xty, j), pyrt::py_mul(rj, yi)))
        for (k in pyrt::py_range_seq(j, p)) {
          pyrt::py_setitem(pyrt::py_getitem(XtX, j), k, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(XtX, j), k), pyrt::py_mul(rj, pyrt::py_getitem(row, k))))
        }
      }
    }
    for (j in pyrt::py_range_seq(p)) {
      for (k in pyrt::py_range_seq(pyrt::py_add(j, 1L), p)) {
        pyrt::py_setitem(pyrt::py_getitem(XtX, k), j, pyrt::py_getitem(pyrt::py_getitem(XtX, j), k))
      }
    }
    for (j in pyrt::py_range_seq(p)) {
      pyrt::py_setitem(pyrt::py_getitem(XtX, j), j, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(XtX, j), j), 1e-09))
    }
    beta <- `_solve_linear_system`(XtX, Xty)
    if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
      pyrt::py_setattr(self, "intercept_", pyrt::py_getitem(beta, 0L))
      pyrt::py_setattr(self, "coef_", pyrt::py_getitem(beta, pyrt::py_slice(1L, NULL, NULL)))
    } else {
      pyrt::py_setattr(self, "intercept_", 0.0)
      pyrt::py_setattr(self, "coef_", beta)
    }
    return(self)
  }
  .py_cdict_8[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    .py_it_24 <- pyrt::py_iter(X)
    repeat {
      .py_step_25 <- pyrt::py_iter_step(.py_it_24)
      if (.py_step_25$stopped) break
      row <- .py_step_25$value
      val <- pyrt::py_getattr(self, "intercept_")
      for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "coef_")))) {
        val <- pyrt::py_add(val, pyrt::py_mul(pyrt::py_getitem(pyrt::py_getattr(self, "coef_"), j), pyrt::py_builtin("float")(pyrt::py_getitem(row, j))))
      }
      pyrt::py_getattr(preds, "append")(val)
    }
    return(preds)
  }
  .py_cdict_8[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(1.0)
    }
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_26", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_27 <- function(.py_sent = NULL) {
          .py_forstep_28 <- pyrt::py_iter_step(.py_forit_26)
          if (.py_forstep_28$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("yi", .py_forstep_28$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_builtin("float")(yi), cont = .py_forloop_27)
        }
        pyrt::py_bounce(.py_forloop_27)
      })
    })()), pyrt::py_builtin("float")(n))
    ss_tot <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_29", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_30 <- function(.py_sent = NULL) {
          .py_forstep_31 <- pyrt::py_iter_step(.py_forit_29)
          if (.py_forstep_31$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_31$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), y_mean), 2L), cont = .py_forloop_30)
        }
        pyrt::py_bounce(.py_forloop_30)
      })
    })())
    ss_res <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_32", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_33 <- function(.py_sent = NULL) {
          .py_forstep_34 <- pyrt::py_iter_step(.py_forit_32)
          if (.py_forstep_34$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_34$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), pyrt::py_getitem(preds, i)), 2L), cont = .py_forloop_33)
        }
        pyrt::py_bounce(.py_forloop_33)
      })
    })())
    if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
      return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
    }
    return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
  }
  .py_cdict_8
})())
Ridge <- pyrt::py_class("Ridge", bases = list(), dict = (function() {
  .py_cdict_35 <- list()
  .py_cdict_35[["__init__"]] <- function(self, alpha = 1.0, fit_intercept = TRUE) {
    pyrt::py_setattr(self, "alpha", pyrt::py_builtin("float")(alpha))
    pyrt::py_setattr(self, "fit_intercept", fit_intercept)
    pyrt::py_setattr(self, "coef_", pyrt::py_list())
    pyrt::py_setattr(self, "intercept_", 0.0)
    pyrt::py_none()
  }
  .py_cdict_35[["fit"]] <- function(self, X, y) {
    n_samples <- pyrt::py_builtin("len")(X)
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
      X_aug <- (function() {
        .py_comp_36 <- list()
        .py_it_40 <- pyrt::py_iter(X)
        repeat {
          .py_step_41 <- pyrt::py_iter_step(.py_it_40)
          if (.py_step_41$stopped) break
          row <- .py_step_41$value
          .py_comp_36[length(.py_comp_36) + 1L] <- list(pyrt::py_add(pyrt::py_list(list(1.0)), (function() {
            .py_comp_37 <- list()
            .py_it_38 <- pyrt::py_iter(row)
            repeat {
              .py_step_39 <- pyrt::py_iter_step(.py_it_38)
              if (.py_step_39$stopped) break
              v <- .py_step_39$value
              .py_comp_37[length(.py_comp_37) + 1L] <- list(pyrt::py_builtin("float")(v))
            }
            pyrt::py_list(.py_comp_37)
          })()))
        }
        pyrt::py_list(.py_comp_36)
      })()
      p <- pyrt::py_add(n_features, 1L)
    } else {
      X_aug <- (function() {
        .py_comp_42 <- list()
        .py_it_46 <- pyrt::py_iter(X)
        repeat {
          .py_step_47 <- pyrt::py_iter_step(.py_it_46)
          if (.py_step_47$stopped) break
          row <- .py_step_47$value
          .py_comp_42[length(.py_comp_42) + 1L] <- list((function() {
            .py_comp_43 <- list()
            .py_it_44 <- pyrt::py_iter(row)
            repeat {
              .py_step_45 <- pyrt::py_iter_step(.py_it_44)
              if (.py_step_45$stopped) break
              v <- .py_step_45$value
              .py_comp_43[length(.py_comp_43) + 1L] <- list(pyrt::py_builtin("float")(v))
            }
            pyrt::py_list(.py_comp_43)
          })())
        }
        pyrt::py_list(.py_comp_42)
      })()
      p <- n_features
    }
    XtX <- (function() {
      .py_comp_48 <- list()
      .py_it_49 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_50 <- pyrt::py_iter_step(.py_it_49)
        if (.py_step_50$stopped) break
        `_` <- .py_step_50$value
        .py_comp_48[length(.py_comp_48) + 1L] <- list(pyrt::py_mul(pyrt::py_list(list(0.0)), p))
      }
      pyrt::py_list(.py_comp_48)
    })()
    Xty <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
    for (i in pyrt::py_range_seq(n_samples)) {
      row <- pyrt::py_getitem(X_aug, i)
      yi <- pyrt::py_builtin("float")(pyrt::py_getitem(y, i))
      for (j in pyrt::py_range_seq(p)) {
        pyrt::py_setitem(Xty, j, pyrt::py_add(pyrt::py_getitem(Xty, j), pyrt::py_mul(pyrt::py_getitem(row, j), yi)))
        for (k in pyrt::py_range_seq(j, p)) {
          pyrt::py_setitem(pyrt::py_getitem(XtX, j), k, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(XtX, j), k), pyrt::py_mul(pyrt::py_getitem(row, j), pyrt::py_getitem(row, k))))
        }
      }
    }
    for (j in pyrt::py_range_seq(p)) {
      for (k in pyrt::py_range_seq(pyrt::py_add(j, 1L), p)) {
        pyrt::py_setitem(pyrt::py_getitem(XtX, k), j, pyrt::py_getitem(pyrt::py_getitem(XtX, j), k))
      }
    }
    start_penalty <- (if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) 1L else 0L)
    for (j in pyrt::py_range_seq(start_penalty, p)) {
      pyrt::py_setitem(pyrt::py_getitem(XtX, j), j, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(XtX, j), j), pyrt::py_getattr(self, "alpha")))
    }
    beta <- `_solve_linear_system`(XtX, Xty)
    if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
      pyrt::py_setattr(self, "intercept_", pyrt::py_getitem(beta, 0L))
      pyrt::py_setattr(self, "coef_", pyrt::py_getitem(beta, pyrt::py_slice(1L, NULL, NULL)))
    } else {
      pyrt::py_setattr(self, "intercept_", 0.0)
      pyrt::py_setattr(self, "coef_", beta)
    }
    return(self)
  }
  .py_cdict_35[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    .py_it_51 <- pyrt::py_iter(X)
    repeat {
      .py_step_52 <- pyrt::py_iter_step(.py_it_51)
      if (.py_step_52$stopped) break
      row <- .py_step_52$value
      val <- pyrt::py_getattr(self, "intercept_")
      for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "coef_")))) {
        val <- pyrt::py_add(val, pyrt::py_mul(pyrt::py_getitem(pyrt::py_getattr(self, "coef_"), j), pyrt::py_builtin("float")(pyrt::py_getitem(row, j))))
      }
      pyrt::py_getattr(preds, "append")(val)
    }
    return(preds)
  }
  .py_cdict_35[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    n <- pyrt::py_builtin("len")(y)
    if (pyrt::py_bool(pyrt::py_le(n, 1L))) {
      return(1.0)
    }
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_53", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_54 <- function(.py_sent = NULL) {
          .py_forstep_55 <- pyrt::py_iter_step(.py_forit_53)
          if (.py_forstep_55$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("yi", .py_forstep_55$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_builtin("float")(yi), cont = .py_forloop_54)
        }
        pyrt::py_bounce(.py_forloop_54)
      })
    })()), pyrt::py_builtin("float")(n))
    ss_tot <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_56", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_57 <- function(.py_sent = NULL) {
          .py_forstep_58 <- pyrt::py_iter_step(.py_forit_56)
          if (.py_forstep_58$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_58$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), y_mean), 2L), cont = .py_forloop_57)
        }
        pyrt::py_bounce(.py_forloop_57)
      })
    })())
    ss_res <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_59", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
        .py_forloop_60 <- function(.py_sent = NULL) {
          .py_forstep_61 <- pyrt::py_iter_step(.py_forit_59)
          if (.py_forstep_61$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_61$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_pow(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), pyrt::py_getitem(preds, i)), 2L), cont = .py_forloop_60)
        }
        pyrt::py_bounce(.py_forloop_60)
      })
    })())
    if (pyrt::py_bool(pyrt::py_eq(ss_tot, 0.0))) {
      return((if (pyrt::py_bool(pyrt::py_eq(ss_res, 0.0))) 1.0 else 0.0))
    }
    return(pyrt::py_sub(1.0, pyrt::py_truediv(ss_res, ss_tot)))
  }
  .py_cdict_35
})())
Lasso <- pyrt::py_class("Lasso", bases = list(), dict = (function() {
  .py_cdict_62 <- list()
  .py_cdict_62[["__init__"]] <- function(self, alpha = 1.0, max_iter = 500L, tol = 1e-04) {
    pyrt::py_setattr(self, "alpha", pyrt::py_builtin("float")(alpha))
    pyrt::py_setattr(self, "max_iter", max_iter)
    pyrt::py_setattr(self, "tol", tol)
    pyrt::py_setattr(self, "coef_", pyrt::py_list())
    pyrt::py_setattr(self, "intercept_", 0.0)
    pyrt::py_none()
  }
  .py_cdict_62[["fit"]] <- function(self, X, y) {
    n <- pyrt::py_builtin("len")(X)
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    y_mean <- pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_63", pyrt::py_iter(y), envir = .py_gen_env)
        .py_forloop_64 <- function(.py_sent = NULL) {
          .py_forstep_65 <- pyrt::py_iter_step(.py_forit_63)
          if (.py_forstep_65$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("v", .py_forstep_65$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_builtin("float")(v), cont = .py_forloop_64)
        }
        pyrt::py_bounce(.py_forloop_64)
      })
    })()), pyrt::py_builtin("float")(n))
    x_means <- (function() {
      .py_comp_66 <- list()
      .py_it_70 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_71 <- pyrt::py_iter_step(.py_it_70)
        if (.py_step_71$stopped) break
        j <- .py_step_71$value
        .py_comp_66[length(.py_comp_66) + 1L] <- list(pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
          .py_gen_env <- environment()
          pyrt::py_generator(function(.py_sent = NULL) {
            assign(".py_forit_67", pyrt::py_iter(X), envir = .py_gen_env)
            .py_forloop_68 <- function(.py_sent = NULL) {
              .py_forstep_69 <- pyrt::py_iter_step(.py_forit_67)
              if (.py_forstep_69$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
              assign("row", .py_forstep_69$value, envir = .py_gen_env)
              pyrt::py_yield(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), cont = .py_forloop_68)
            }
            pyrt::py_bounce(.py_forloop_68)
          })
        })()), pyrt::py_builtin("float")(n)))
      }
      pyrt::py_list(.py_comp_66)
    })()
    Xc <- (function() {
      .py_comp_72 <- list()
      .py_it_76 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_77 <- pyrt::py_iter_step(.py_it_76)
        if (.py_step_77$stopped) break
        i <- .py_step_77$value
        .py_comp_72[length(.py_comp_72) + 1L] <- list((function() {
          .py_comp_73 <- list()
          .py_it_74 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
          repeat {
            .py_step_75 <- pyrt::py_iter_step(.py_it_74)
            if (.py_step_75$stopped) break
            j <- .py_step_75$value
            .py_comp_73[length(.py_comp_73) + 1L] <- list(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j)), pyrt::py_getitem(x_means, j)))
          }
          pyrt::py_list(.py_comp_73)
        })())
      }
      pyrt::py_list(.py_comp_72)
    })()
    yc <- (function() {
      .py_comp_78 <- list()
      .py_it_79 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_80 <- pyrt::py_iter_step(.py_it_79)
        if (.py_step_80$stopped) break
        i <- .py_step_80$value
        .py_comp_78[length(.py_comp_78) + 1L] <- list(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(y, i)), y_mean))
      }
      pyrt::py_list(.py_comp_78)
    })()
    z <- (function() {
      .py_comp_81 <- list()
      .py_it_85 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_86 <- pyrt::py_iter_step(.py_it_85)
        if (.py_step_86$stopped) break
        j <- .py_step_86$value
        .py_comp_81[length(.py_comp_81) + 1L] <- list(pyrt::py_builtin("sum")((function() {
          .py_gen_env <- environment()
          pyrt::py_generator(function(.py_sent = NULL) {
            assign(".py_forit_82", pyrt::py_iter(pyrt::py_builtin("range")(n)), envir = .py_gen_env)
            .py_forloop_83 <- function(.py_sent = NULL) {
              .py_forstep_84 <- pyrt::py_iter_step(.py_forit_82)
              if (.py_forstep_84$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
              assign("i", .py_forstep_84$value, envir = .py_gen_env)
              pyrt::py_yield(pyrt::py_pow(pyrt::py_getitem(pyrt::py_getitem(Xc, i), j), 2L), cont = .py_forloop_83)
            }
            pyrt::py_bounce(.py_forloop_83)
          })
        })()))
      }
      pyrt::py_list(.py_comp_81)
    })()
    for (j in pyrt::py_range_seq(p)) {
      if (pyrt::py_bool(pyrt::py_lt(pyrt::py_getitem(z, j), 1e-12))) {
        pyrt::py_setitem(z, j, 1e-12)
      }
    }
    w <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
    r <- pyrt::py_builtin("list")(yc)
    for (`_` in pyrt::py_range_seq(pyrt::py_getattr(self, "max_iter"))) {
      max_change <- 0.0
      for (j in pyrt::py_range_seq(p)) {
        wj_old <- pyrt::py_getitem(w, j)
        rho_j <- 0.0
        for (i in pyrt::py_range_seq(n)) {
          r_no_j <- pyrt::py_add(pyrt::py_getitem(r, i), pyrt::py_mul(pyrt::py_getitem(pyrt::py_getitem(Xc, i), j), wj_old))
          rho_j <- pyrt::py_add(rho_j, pyrt::py_mul(pyrt::py_getitem(pyrt::py_getitem(Xc, i), j), r_no_j))
        }
        gamma <- pyrt::py_mul(pyrt::py_getattr(self, "alpha"), pyrt::py_builtin("float")(n))
        if (pyrt::py_bool(pyrt::py_gt(rho_j, gamma))) {
          w_new <- pyrt::py_truediv(pyrt::py_sub(rho_j, gamma), pyrt::py_getitem(z, j))
        } else if (pyrt::py_bool(pyrt::py_lt(rho_j, pyrt::py_neg(gamma)))) {
          w_new <- pyrt::py_truediv(pyrt::py_add(rho_j, gamma), pyrt::py_getitem(z, j))
        } else {
          w_new <- 0.0
        }
        diff <- pyrt::py_builtin("abs")(pyrt::py_sub(w_new, wj_old))
        if (pyrt::py_bool(pyrt::py_gt(diff, max_change))) {
          max_change <- diff
        }
        for (i in pyrt::py_range_seq(n)) {
          pyrt::py_setitem(r, i, pyrt::py_sub(pyrt::py_getitem(r, i), pyrt::py_mul(pyrt::py_getitem(pyrt::py_getitem(Xc, i), j), pyrt::py_sub(w_new, wj_old))))
        }
        pyrt::py_setitem(w, j, w_new)
      }
      if (pyrt::py_bool(pyrt::py_lt(max_change, pyrt::py_getattr(self, "tol")))) {
        break
      }
    }
    pyrt::py_setattr(self, "coef_", w)
    pyrt::py_setattr(self, "intercept_", pyrt::py_sub(y_mean, pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_87", pyrt::py_iter(pyrt::py_builtin("range")(p)), envir = .py_gen_env)
        .py_forloop_88 <- function(.py_sent = NULL) {
          .py_forstep_89 <- pyrt::py_iter_step(.py_forit_87)
          if (.py_forstep_89$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("j", .py_forstep_89$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_mul(pyrt::py_getitem(w, j), pyrt::py_getitem(x_means, j)), cont = .py_forloop_88)
        }
        pyrt::py_bounce(.py_forloop_88)
      })
    })())))
    return(self)
  }
  .py_cdict_62[["predict"]] <- function(self, X) {
    preds <- pyrt::py_list()
    .py_it_90 <- pyrt::py_iter(X)
    repeat {
      .py_step_91 <- pyrt::py_iter_step(.py_it_90)
      if (.py_step_91$stopped) break
      row <- .py_step_91$value
      val <- pyrt::py_getattr(self, "intercept_")
      for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "coef_")))) {
        val <- pyrt::py_add(val, pyrt::py_mul(pyrt::py_getitem(pyrt::py_getattr(self, "coef_"), j), pyrt::py_builtin("float")(pyrt::py_getitem(row, j))))
      }
      pyrt::py_getattr(preds, "append")(val)
    }
    return(preds)
  }
  .py_cdict_62
})())
LogisticRegression <- pyrt::py_class("LogisticRegression", bases = list(), dict = (function() {
  .py_cdict_92 <- list()
  .py_cdict_92[["__init__"]] <- function(self, C = 1.0, max_iter = 200L, fit_intercept = TRUE, lr = 0.1) {
    pyrt::py_setattr(self, "C", pyrt::py_builtin("float")(C))
    pyrt::py_setattr(self, "lr", pyrt::py_builtin("float")(lr))
    pyrt::py_setattr(self, "max_iter", max_iter)
    pyrt::py_setattr(self, "fit_intercept", fit_intercept)
    pyrt::py_setattr(self, "coef_", pyrt::py_list())
    pyrt::py_setattr(self, "intercept_", 0.0)
    pyrt::py_setattr(self, "classes_", pyrt::py_list(list(0L, 1L)))
    pyrt::py_none()
  }
  .py_cdict_92[["_sigmoid"]] <- function(self, z) {
    if (pyrt::py_bool(pyrt::py_lt(z, pyrt::py_neg(20.0)))) {
      return(0.0)
    }
    if (pyrt::py_bool(pyrt::py_gt(z, 20.0))) {
      return(1.0)
    }
    return(pyrt::py_truediv(1.0, pyrt::py_add(1.0, pyrt::py_getattr(math, "exp")(pyrt::py_neg(z)))))
  }
  .py_cdict_92[["fit"]] <- function(self, X, y) {
    n <- pyrt::py_builtin("len")(X)
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    w <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
    b <- 0.0
    for (`_` in pyrt::py_range_seq(pyrt::py_getattr(self, "max_iter"))) {
      grad_w <- pyrt::py_mul(pyrt::py_list(list(0.0)), p)
      grad_b <- 0.0
      for (i in pyrt::py_range_seq(n)) {
        z <- b
        for (j in pyrt::py_range_seq(p)) {
          z <- pyrt::py_add(z, pyrt::py_mul(pyrt::py_getitem(w, j), pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j))))
        }
        p_i <- pyrt::py_getattr(self, "_sigmoid")(z)
        err <- pyrt::py_sub(p_i, pyrt::py_builtin("float")(pyrt::py_getitem(y, i)))
        for (j in pyrt::py_range_seq(p)) {
          pyrt::py_setitem(grad_w, j, pyrt::py_add(pyrt::py_getitem(grad_w, j), pyrt::py_mul(err, pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j)))))
        }
        if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
          grad_b <- pyrt::py_add(grad_b, err)
        }
      }
      inv_n <- pyrt::py_truediv(pyrt::py_getattr(self, "lr"), pyrt::py_builtin("float")(n))
      for (j in pyrt::py_range_seq(p)) {
        pyrt::py_setitem(w, j, pyrt::py_sub(pyrt::py_getitem(w, j), pyrt::py_mul(pyrt::py_getitem(grad_w, j), inv_n)))
      }
      if (pyrt::py_bool(pyrt::py_getattr(self, "fit_intercept"))) {
        b <- pyrt::py_sub(b, pyrt::py_mul(grad_b, inv_n))
      }
    }
    pyrt::py_setattr(self, "coef_", w)
    pyrt::py_setattr(self, "intercept_", b)
    return(self)
  }
  .py_cdict_92[["predict_proba"]] <- function(self, X) {
    probs <- pyrt::py_list()
    .py_it_93 <- pyrt::py_iter(X)
    repeat {
      .py_step_94 <- pyrt::py_iter_step(.py_it_93)
      if (.py_step_94$stopped) break
      row <- .py_step_94$value
      z <- pyrt::py_getattr(self, "intercept_")
      for (j in pyrt::py_range_seq(pyrt::py_builtin("len")(pyrt::py_getattr(self, "coef_")))) {
        z <- pyrt::py_add(z, pyrt::py_mul(pyrt::py_getitem(pyrt::py_getattr(self, "coef_"), j), pyrt::py_builtin("float")(pyrt::py_getitem(row, j))))
      }
      p1 <- pyrt::py_getattr(self, "_sigmoid")(z)
      pyrt::py_getattr(probs, "append")(pyrt::py_list(list(pyrt::py_sub(1.0, p1), p1)))
    }
    return(probs)
  }
  .py_cdict_92[["predict"]] <- function(self, X) {
    probs <- pyrt::py_getattr(self, "predict_proba")(X)
    return((function() {
      .py_comp_95 <- list()
      .py_it_96 <- pyrt::py_iter(probs)
      repeat {
        .py_step_97 <- pyrt::py_iter_step(.py_it_96)
        if (.py_step_97$stopped) break
        p <- .py_step_97$value
        .py_comp_95[length(.py_comp_95) + 1L] <- list((if (pyrt::py_bool(pyrt::py_ge(pyrt::py_getitem(p, 1L), 0.5))) 1L else 0L))
      }
      pyrt::py_list(.py_comp_95)
    })())
  }
  .py_cdict_92[["score"]] <- function(self, X, y) {
    preds <- pyrt::py_getattr(self, "predict")(X)
    correct <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_98", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(y))), envir = .py_gen_env)
        .py_forloop_99 <- function(.py_sent = NULL) {
          .py_forstep_100 <- pyrt::py_iter_step(.py_forit_98)
          if (.py_forstep_100$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("i", .py_forstep_100$value, envir = .py_gen_env)
          if (pyrt::py_bool(pyrt::py_eq(pyrt::py_getitem(preds, i), pyrt::py_builtin("int")(pyrt::py_getitem(y, i))))) {
            pyrt::py_yield(1L, cont = .py_forloop_99)
          } else {
            pyrt::py_bounce(.py_forloop_99)
          }
        }
        pyrt::py_bounce(.py_forloop_99)
      })
    })())
    return(pyrt::py_truediv(pyrt::py_builtin("float")(correct), pyrt::py_builtin("float")(pyrt::py_builtin("len")(y))))
  }
  .py_cdict_92
})())
