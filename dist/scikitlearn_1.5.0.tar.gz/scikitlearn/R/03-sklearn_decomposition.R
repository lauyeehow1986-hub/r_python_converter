# Transpiled from Python module: sklearn/decomposition.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
math <- pyrt::py_stdlib("math")
`_mat_vec_mul` <- function(A, v) {
  p <- pyrt::py_builtin("len")(v)
  return((function() {
    .py_comp_1 <- list()
    .py_it_5 <- pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(A)))
    repeat {
      .py_step_6 <- pyrt::py_iter_step(.py_it_5)
      if (.py_step_6$stopped) break
      i <- .py_step_6$value
      .py_comp_1[length(.py_comp_1) + 1L] <- list(pyrt::py_builtin("sum")((function() {
        .py_gen_env <- environment()
        pyrt::py_generator(function(.py_sent = NULL) {
          assign(".py_forit_2", pyrt::py_iter(pyrt::py_builtin("range")(p)), envir = .py_gen_env)
          .py_forloop_3 <- function(.py_sent = NULL) {
            .py_forstep_4 <- pyrt::py_iter_step(.py_forit_2)
            if (.py_forstep_4$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
            assign("j", .py_forstep_4$value, envir = .py_gen_env)
            pyrt::py_yield(pyrt::py_mul(pyrt::py_getitem(pyrt::py_getitem(A, i), j), pyrt::py_getitem(v, j)), cont = .py_forloop_3)
          }
          pyrt::py_bounce(.py_forloop_3)
        })
      })()))
    }
    pyrt::py_list(.py_comp_1)
  })())
}
`_dot` <- function(v1, v2) {
  return(pyrt::py_builtin("sum")((function() {
    .py_gen_env <- environment()
    pyrt::py_generator(function(.py_sent = NULL) {
      assign(".py_forit_7", pyrt::py_iter(pyrt::py_builtin("range")(pyrt::py_builtin("len")(v1))), envir = .py_gen_env)
      .py_forloop_8 <- function(.py_sent = NULL) {
        .py_forstep_9 <- pyrt::py_iter_step(.py_forit_7)
        if (.py_forstep_9$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
        assign("i", .py_forstep_9$value, envir = .py_gen_env)
        pyrt::py_yield(pyrt::py_mul(pyrt::py_getitem(v1, i), pyrt::py_getitem(v2, i)), cont = .py_forloop_8)
      }
      pyrt::py_bounce(.py_forloop_8)
    })
  })()))
}
`_power_iteration` <- function(A, num_iter = 100L) {
  p <- pyrt::py_builtin("len")(A)
  v <- pyrt::py_mul(pyrt::py_list(list(pyrt::py_truediv(1.0, pyrt::py_getattr(math, "sqrt")(p)))), p)
  for (`_` in pyrt::py_range_seq(num_iter)) {
    w <- `_mat_vec_mul`(A, v)
    norm <- pyrt::py_getattr(math, "sqrt")(`_dot`(w, w))
    if (pyrt::py_bool(pyrt::py_lt(norm, 1e-12))) {
      break
    }
    v <- (function() {
      .py_comp_10 <- list()
      .py_it_11 <- pyrt::py_iter(w)
      repeat {
        .py_step_12 <- pyrt::py_iter_step(.py_it_11)
        if (.py_step_12$stopped) break
        x <- .py_step_12$value
        .py_comp_10[length(.py_comp_10) + 1L] <- list(pyrt::py_truediv(x, norm))
      }
      pyrt::py_list(.py_comp_10)
    })()
  }
  Av <- `_mat_vec_mul`(A, v)
  eigenval <- `_dot`(v, Av)
  return(pyrt::py_tuple(list(eigenval, v)))
}
PCA <- pyrt::py_class("PCA", bases = list(), dict = (function() {
  .py_cdict_13 <- list()
  .py_cdict_13[["__init__"]] <- function(self, n_components = 2L) {
    pyrt::py_setattr(self, "n_components", pyrt::py_builtin("int")(n_components))
    pyrt::py_setattr(self, "mean_", pyrt::py_list())
    pyrt::py_setattr(self, "components_", pyrt::py_list())
    pyrt::py_setattr(self, "explained_variance_", pyrt::py_list())
    pyrt::py_setattr(self, "explained_variance_ratio_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_13[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n <- pyrt::py_builtin("len")(X)
    p <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    k <- pyrt::py_builtin("min")(pyrt::py_getattr(self, "n_components"), p, n)
    means <- (function() {
      .py_comp_14 <- list()
      .py_it_18 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_19 <- pyrt::py_iter_step(.py_it_18)
        if (.py_step_19$stopped) break
        j <- .py_step_19$value
        .py_comp_14[length(.py_comp_14) + 1L] <- list(pyrt::py_truediv(pyrt::py_builtin("sum")((function() {
          .py_gen_env <- environment()
          pyrt::py_generator(function(.py_sent = NULL) {
            assign(".py_forit_15", pyrt::py_iter(X), envir = .py_gen_env)
            .py_forloop_16 <- function(.py_sent = NULL) {
              .py_forstep_17 <- pyrt::py_iter_step(.py_forit_15)
              if (.py_forstep_17$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
              assign("row", .py_forstep_17$value, envir = .py_gen_env)
              pyrt::py_yield(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), cont = .py_forloop_16)
            }
            pyrt::py_bounce(.py_forloop_16)
          })
        })()), pyrt::py_builtin("float")(n)))
      }
      pyrt::py_list(.py_comp_14)
    })()
    pyrt::py_setattr(self, "mean_", means)
    Xc <- (function() {
      .py_comp_20 <- list()
      .py_it_24 <- pyrt::py_iter(pyrt::py_builtin("range")(n))
      repeat {
        .py_step_25 <- pyrt::py_iter_step(.py_it_24)
        if (.py_step_25$stopped) break
        i <- .py_step_25$value
        .py_comp_20[length(.py_comp_20) + 1L] <- list((function() {
          .py_comp_21 <- list()
          .py_it_22 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
          repeat {
            .py_step_23 <- pyrt::py_iter_step(.py_it_22)
            if (.py_step_23$stopped) break
            j <- .py_step_23$value
            .py_comp_21[length(.py_comp_21) + 1L] <- list(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, i), j)), pyrt::py_getitem(means, j)))
          }
          pyrt::py_list(.py_comp_21)
        })())
      }
      pyrt::py_list(.py_comp_20)
    })()
    C <- (function() {
      .py_comp_26 <- list()
      .py_it_27 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
      repeat {
        .py_step_28 <- pyrt::py_iter_step(.py_it_27)
        if (.py_step_28$stopped) break
        `_` <- .py_step_28$value
        .py_comp_26[length(.py_comp_26) + 1L] <- list(pyrt::py_mul(pyrt::py_list(list(0.0)), p))
      }
      pyrt::py_list(.py_comp_26)
    })()
    denom <- pyrt::py_builtin("float")(pyrt::py_builtin("max")(1L, pyrt::py_sub(n, 1L)))
    for (i in pyrt::py_range_seq(n)) {
      row <- pyrt::py_getitem(Xc, i)
      for (j in pyrt::py_range_seq(p)) {
        for (m in pyrt::py_range_seq(j, p)) {
          pyrt::py_setitem(pyrt::py_getitem(C, j), m, pyrt::py_add(pyrt::py_getitem(pyrt::py_getitem(C, j), m), pyrt::py_mul(pyrt::py_getitem(row, j), pyrt::py_getitem(row, m))))
        }
      }
    }
    for (j in pyrt::py_range_seq(p)) {
      for (m in pyrt::py_range_seq(j, p)) {
        val <- pyrt::py_truediv(pyrt::py_getitem(pyrt::py_getitem(C, j), m), denom)
        pyrt::py_setitem(pyrt::py_getitem(C, j), m, val)
        pyrt::py_setitem(pyrt::py_getitem(C, m), j, val)
      }
    }
    total_var <- pyrt::py_builtin("sum")((function() {
      .py_gen_env <- environment()
      pyrt::py_generator(function(.py_sent = NULL) {
        assign(".py_forit_29", pyrt::py_iter(pyrt::py_builtin("range")(p)), envir = .py_gen_env)
        .py_forloop_30 <- function(.py_sent = NULL) {
          .py_forstep_31 <- pyrt::py_iter_step(.py_forit_29)
          if (.py_forstep_31$stopped) return(pyrt::py_bounce(function() pyrt::py_stop_iteration()))
          assign("j", .py_forstep_31$value, envir = .py_gen_env)
          pyrt::py_yield(pyrt::py_getitem(pyrt::py_getitem(C, j), j), cont = .py_forloop_30)
        }
        pyrt::py_bounce(.py_forloop_30)
      })
    })())
    if (pyrt::py_bool(pyrt::py_lt(total_var, 1e-12))) {
      total_var <- 1e-12
    }
    components <- pyrt::py_list()
    explained_var <- pyrt::py_list()
    explained_ratio <- pyrt::py_list()
    C_deflated <- (function() {
      .py_comp_32 <- list()
      .py_it_33 <- pyrt::py_iter(C)
      repeat {
        .py_step_34 <- pyrt::py_iter_step(.py_it_33)
        if (.py_step_34$stopped) break
        row <- .py_step_34$value
        .py_comp_32[length(.py_comp_32) + 1L] <- list(pyrt::py_builtin("list")(row))
      }
      pyrt::py_list(.py_comp_32)
    })()
    for (`_` in pyrt::py_range_seq(k)) {
      .py_unp_35 <- pyrt::py_unpack(`_power_iteration`(C_deflated, num_iter = 80L), 2L)
      val <- .py_unp_35[[1L]]
      vec <- .py_unp_35[[2L]]
      pyrt::py_getattr(components, "append")(vec)
      pyrt::py_getattr(explained_var, "append")(pyrt::py_builtin("max")(0.0, val))
      pyrt::py_getattr(explained_ratio, "append")(pyrt::py_truediv(pyrt::py_builtin("max")(0.0, val), total_var))
      for (r in pyrt::py_range_seq(p)) {
        for (c in pyrt::py_range_seq(p)) {
          pyrt::py_setitem(pyrt::py_getitem(C_deflated, r), c, pyrt::py_sub(pyrt::py_getitem(pyrt::py_getitem(C_deflated, r), c), pyrt::py_mul(pyrt::py_mul(val, pyrt::py_getitem(vec, r)), pyrt::py_getitem(vec, c))))
        }
      }
    }
    pyrt::py_setattr(self, "components_", components)
    pyrt::py_setattr(self, "explained_variance_", explained_var)
    pyrt::py_setattr(self, "explained_variance_ratio_", explained_ratio)
    return(self)
  }
  .py_cdict_13[["transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    p <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "mean_"))
    .py_it_36 <- pyrt::py_iter(X)
    repeat {
      .py_step_37 <- pyrt::py_iter_step(.py_it_36)
      if (.py_step_37$stopped) break
      row <- .py_step_37$value
      centered <- (function() {
        .py_comp_38 <- list()
        .py_it_39 <- pyrt::py_iter(pyrt::py_builtin("range")(p))
        repeat {
          .py_step_40 <- pyrt::py_iter_step(.py_it_39)
          if (.py_step_40$stopped) break
          j <- .py_step_40$value
          .py_comp_38[length(.py_comp_38) + 1L] <- list(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), pyrt::py_getitem(pyrt::py_getattr(self, "mean_"), j)))
        }
        pyrt::py_list(.py_comp_38)
      })()
      proj <- (function() {
        .py_comp_41 <- list()
        .py_it_42 <- pyrt::py_iter(pyrt::py_getattr(self, "components_"))
        repeat {
          .py_step_43 <- pyrt::py_iter_step(.py_it_42)
          if (.py_step_43$stopped) break
          comp <- .py_step_43$value
          .py_comp_41[length(.py_comp_41) + 1L] <- list(`_dot`(comp, centered))
        }
        pyrt::py_list(.py_comp_41)
      })()
      pyrt::py_getattr(out, "append")(proj)
    }
    return(out)
  }
  .py_cdict_13[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "transform")(X))
  }
  .py_cdict_13[["inverse_transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    p <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "mean_"))
    k <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "components_"))
    .py_it_44 <- pyrt::py_iter(X)
    repeat {
      .py_step_45 <- pyrt::py_iter_step(.py_it_44)
      if (.py_step_45$stopped) break
      row <- .py_step_45$value
      reconstructed <- pyrt::py_builtin("list")(pyrt::py_getattr(self, "mean_"))
      for (comp_idx in pyrt::py_range_seq(k)) {
        coeff <- pyrt::py_builtin("float")(pyrt::py_getitem(row, comp_idx))
        for (j in pyrt::py_range_seq(p)) {
          pyrt::py_setitem(reconstructed, j, pyrt::py_add(pyrt::py_getitem(reconstructed, j), pyrt::py_mul(coeff, pyrt::py_getitem(pyrt::py_getitem(pyrt::py_getattr(self, "components_"), comp_idx), j))))
        }
      }
      pyrt::py_getattr(out, "append")(reconstructed)
    }
    return(out)
  }
  .py_cdict_13
})())
