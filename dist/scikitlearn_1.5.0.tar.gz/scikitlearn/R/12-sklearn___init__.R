# Transpiled from Python module: sklearn/__init__.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
`__version__` <- "1.5.0"
`__author__` <- "scikit-learn developers / ported by Yee How Lau"
`__all__` <- pyrt::py_list(list("StandardScaler", "MinMaxScaler", "RobustScaler", "Binarizer", "LabelEncoder", "LinearRegression", "Ridge", "Lasso", "LogisticRegression", "KMeans", "DBSCAN", "KNeighborsClassifier", "KNeighborsRegressor", "DecisionTreeClassifier", "DecisionTreeRegressor", "GaussianNB", "PCA", "accuracy_score", "precision_score", "recall_score", "f1_score", "confusion_matrix", "roc_auc_score", "mean_squared_error", "mean_absolute_error", "r2_score", "train_test_split", "KFold", "Pipeline"))
