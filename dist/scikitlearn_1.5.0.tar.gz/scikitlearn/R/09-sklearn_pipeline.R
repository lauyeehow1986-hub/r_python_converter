# Transpiled from Python module: sklearn/pipeline.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
Pipeline <- pyrt::py_class("Pipeline", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, steps) {
    pyrt::py_setattr(self, "steps", steps)
    pyrt::py_setattr(self, "named_steps", (function() {
      .py_comp_2 <- pyrt::py_dict()
      .py_it_3 <- pyrt::py_iter(steps)
      repeat {
        .py_step_4 <- pyrt::py_iter_step(.py_it_3)
        if (.py_step_4$stopped) break
        .py_unp_5 <- pyrt::py_unpack(.py_step_4$value, 2L)
        name <- .py_unp_5[[1L]]
        step <- .py_unp_5[[2L]]
        .py_comp_2$set(name, step)
      }
      .py_comp_2
    })())
    pyrt::py_none()
  }
  .py_cdict_1[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    Xt <- X
    for (i in pyrt::py_range_seq(pyrt::py_sub(pyrt::py_builtin("len")(pyrt::py_getattr(self, "steps")), 1L))) {
      .py_unp_6 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), i), 2L)
      name <- .py_unp_6[[1L]]
      transform <- .py_unp_6[[2L]]
      Xt <- pyrt::py_getattr(transform, "fit_transform")(Xt, y)
    }
    .py_unp_7 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), pyrt::py_neg(1L)), 2L)
    final_name <- .py_unp_7[[1L]]
    final_estimator <- .py_unp_7[[2L]]
    pyrt::py_getattr(final_estimator, "fit")(Xt, y)
    return(self)
  }
  .py_cdict_1[["predict"]] <- function(self, X) {
    Xt <- X
    for (i in pyrt::py_range_seq(pyrt::py_sub(pyrt::py_builtin("len")(pyrt::py_getattr(self, "steps")), 1L))) {
      .py_unp_8 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), i), 2L)
      name <- .py_unp_8[[1L]]
      transform <- .py_unp_8[[2L]]
      Xt <- pyrt::py_getattr(transform, "transform")(Xt)
    }
    .py_unp_9 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), pyrt::py_neg(1L)), 2L)
    final_name <- .py_unp_9[[1L]]
    final_estimator <- .py_unp_9[[2L]]
    return(pyrt::py_getattr(final_estimator, "predict")(Xt))
  }
  .py_cdict_1[["fit_predict"]] <- function(self, X, y = pyrt::py_none()) {
    pyrt::py_getattr(self, "fit")(X, y)
    return(pyrt::py_getattr(self, "predict")(X))
  }
  .py_cdict_1[["score"]] <- function(self, X, y) {
    Xt <- X
    for (i in pyrt::py_range_seq(pyrt::py_sub(pyrt::py_builtin("len")(pyrt::py_getattr(self, "steps")), 1L))) {
      .py_unp_10 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), i), 2L)
      name <- .py_unp_10[[1L]]
      transform <- .py_unp_10[[2L]]
      Xt <- pyrt::py_getattr(transform, "transform")(Xt)
    }
    .py_unp_11 <- pyrt::py_unpack(pyrt::py_getitem(pyrt::py_getattr(self, "steps"), pyrt::py_neg(1L)), 2L)
    final_name <- .py_unp_11[[1L]]
    final_estimator <- .py_unp_11[[2L]]
    return(pyrt::py_getattr(final_estimator, "score")(Xt, y))
  }
  .py_cdict_1
})())
