# Transpiled from Python module: sklearn/preprocessing.py
if (!exists(".py_mod_env", inherits = FALSE)) .py_mod_env <- environment()
math <- pyrt::py_stdlib("math")
StandardScaler <- pyrt::py_class("StandardScaler", bases = list(), dict = (function() {
  .py_cdict_1 <- list()
  .py_cdict_1[["__init__"]] <- function(self, with_mean = TRUE, with_std = TRUE) {
    pyrt::py_setattr(self, "with_mean", with_mean)
    pyrt::py_setattr(self, "with_std", with_std)
    pyrt::py_setattr(self, "mean_", pyrt::py_list())
    pyrt::py_setattr(self, "var_", pyrt::py_list())
    pyrt::py_setattr(self, "scale_", pyrt::py_list())
    pyrt::py_setattr(self, "n_samples_seen_", 0L)
    pyrt::py_none()
  }
  .py_cdict_1[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n_samples <- pyrt::py_builtin("len")(X)
    if (pyrt::py_bool(pyrt::py_eq(n_samples, 0L))) {
      return(self)
    }
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    pyrt::py_setattr(self, "n_samples_seen_", n_samples)
    means <- pyrt::py_mul(pyrt::py_list(list(0.0)), n_features)
    .py_it_2 <- pyrt::py_iter(X)
    repeat {
      .py_step_3 <- pyrt::py_iter_step(.py_it_2)
      if (.py_step_3$stopped) break
      row <- .py_step_3$value
      for (j in pyrt::py_range_seq(n_features)) {
        pyrt::py_setitem(means, j, pyrt::py_add(pyrt::py_getitem(means, j), pyrt::py_builtin("float")(pyrt::py_getitem(row, j))))
      }
    }
    for (j in pyrt::py_range_seq(n_features)) {
      pyrt::py_setitem(means, j, pyrt::py_truediv(pyrt::py_getitem(means, j), pyrt::py_builtin("float")(n_samples)))
    }
    vars_ <- pyrt::py_mul(pyrt::py_list(list(0.0)), n_features)
    .py_it_4 <- pyrt::py_iter(X)
    repeat {
      .py_step_5 <- pyrt::py_iter_step(.py_it_4)
      if (.py_step_5$stopped) break
      row <- .py_step_5$value
      for (j in pyrt::py_range_seq(n_features)) {
        diff <- pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), pyrt::py_getitem(means, j))
        pyrt::py_setitem(vars_, j, pyrt::py_add(pyrt::py_getitem(vars_, j), pyrt::py_mul(diff, diff)))
      }
    }
    for (j in pyrt::py_range_seq(n_features)) {
      pyrt::py_setitem(vars_, j, pyrt::py_truediv(pyrt::py_getitem(vars_, j), pyrt::py_builtin("float")(n_samples)))
    }
    scales <- pyrt::py_list()
    for (j in pyrt::py_range_seq(n_features)) {
      s <- pyrt::py_getattr(math, "sqrt")(pyrt::py_getitem(vars_, j))
      pyrt::py_getattr(scales, "append")((if (pyrt::py_bool(pyrt::py_gt(s, 1e-12))) s else 1.0))
    }
    pyrt::py_setattr(self, "mean_", means)
    pyrt::py_setattr(self, "var_", vars_)
    pyrt::py_setattr(self, "scale_", scales)
    return(self)
  }
  .py_cdict_1[["transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    n_features <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "mean_"))
    .py_it_6 <- pyrt::py_iter(X)
    repeat {
      .py_step_7 <- pyrt::py_iter_step(.py_it_6)
      if (.py_step_7$stopped) break
      row <- .py_step_7$value
      scaled_row <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_builtin("float")(pyrt::py_getitem(row, j))
        if (pyrt::py_bool(pyrt::py_getattr(self, "with_mean"))) {
          val <- pyrt::py_sub(val, pyrt::py_getitem(pyrt::py_getattr(self, "mean_"), j))
        }
        if (pyrt::py_bool(pyrt::py_getattr(self, "with_std"))) {
          val <- pyrt::py_truediv(val, pyrt::py_getitem(pyrt::py_getattr(self, "scale_"), j))
        }
        pyrt::py_getattr(scaled_row, "append")(val)
      }
      pyrt::py_getattr(out, "append")(scaled_row)
    }
    return(out)
  }
  .py_cdict_1[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "transform")(X))
  }
  .py_cdict_1[["inverse_transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    n_features <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "mean_"))
    .py_it_8 <- pyrt::py_iter(X)
    repeat {
      .py_step_9 <- pyrt::py_iter_step(.py_it_8)
      if (.py_step_9$stopped) break
      row <- .py_step_9$value
      orig_row <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_builtin("float")(pyrt::py_getitem(row, j))
        if (pyrt::py_bool(pyrt::py_getattr(self, "with_std"))) {
          val <- pyrt::py_mul(val, pyrt::py_getitem(pyrt::py_getattr(self, "scale_"), j))
        }
        if (pyrt::py_bool(pyrt::py_getattr(self, "with_mean"))) {
          val <- pyrt::py_add(val, pyrt::py_getitem(pyrt::py_getattr(self, "mean_"), j))
        }
        pyrt::py_getattr(orig_row, "append")(val)
      }
      pyrt::py_getattr(out, "append")(orig_row)
    }
    return(out)
  }
  .py_cdict_1
})())
MinMaxScaler <- pyrt::py_class("MinMaxScaler", bases = list(), dict = (function() {
  .py_cdict_10 <- list()
  .py_cdict_10[["__init__"]] <- function(self, feature_range = pyrt::py_tuple(list(0.0, 1.0))) {
    pyrt::py_setattr(self, "feature_range", feature_range)
    pyrt::py_setattr(self, "data_min_", pyrt::py_list())
    pyrt::py_setattr(self, "data_max_", pyrt::py_list())
    pyrt::py_setattr(self, "data_range_", pyrt::py_list())
    pyrt::py_setattr(self, "scale_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_10[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n_samples <- pyrt::py_builtin("len")(X)
    if (pyrt::py_bool(pyrt::py_eq(n_samples, 0L))) {
      return(self)
    }
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    mins <- (function() {
      .py_comp_11 <- list()
      .py_it_12 <- pyrt::py_iter(pyrt::py_builtin("range")(n_features))
      repeat {
        .py_step_13 <- pyrt::py_iter_step(.py_it_12)
        if (.py_step_13$stopped) break
        j <- .py_step_13$value
        .py_comp_11[length(.py_comp_11) + 1L] <- list(pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, 0L), j)))
      }
      pyrt::py_list(.py_comp_11)
    })()
    maxs <- (function() {
      .py_comp_14 <- list()
      .py_it_15 <- pyrt::py_iter(pyrt::py_builtin("range")(n_features))
      repeat {
        .py_step_16 <- pyrt::py_iter_step(.py_it_15)
        if (.py_step_16$stopped) break
        j <- .py_step_16$value
        .py_comp_14[length(.py_comp_14) + 1L] <- list(pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getitem(X, 0L), j)))
      }
      pyrt::py_list(.py_comp_14)
    })()
    .py_it_17 <- pyrt::py_iter(X)
    repeat {
      .py_step_18 <- pyrt::py_iter_step(.py_it_17)
      if (.py_step_18$stopped) break
      row <- .py_step_18$value
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_builtin("float")(pyrt::py_getitem(row, j))
        if (pyrt::py_bool(pyrt::py_lt(val, pyrt::py_getitem(mins, j)))) {
          pyrt::py_setitem(mins, j, val)
        }
        if (pyrt::py_bool(pyrt::py_gt(val, pyrt::py_getitem(maxs, j)))) {
          pyrt::py_setitem(maxs, j, val)
        }
      }
    }
    ranges <- pyrt::py_list()
    scales <- pyrt::py_list()
    target_range <- pyrt::py_builtin("float")(pyrt::py_sub(pyrt::py_getitem(pyrt::py_getattr(self, "feature_range"), 1L), pyrt::py_getitem(pyrt::py_getattr(self, "feature_range"), 0L)))
    for (j in pyrt::py_range_seq(n_features)) {
      rng <- pyrt::py_sub(pyrt::py_getitem(maxs, j), pyrt::py_getitem(mins, j))
      pyrt::py_getattr(ranges, "append")(rng)
      pyrt::py_getattr(scales, "append")((if (pyrt::py_bool(pyrt::py_gt(rng, 1e-12))) pyrt::py_truediv(target_range, rng) else 1.0))
    }
    pyrt::py_setattr(self, "data_min_", mins)
    pyrt::py_setattr(self, "data_max_", maxs)
    pyrt::py_setattr(self, "data_range_", ranges)
    pyrt::py_setattr(self, "scale_", scales)
    return(self)
  }
  .py_cdict_10[["transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    n_features <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "data_min_"))
    t_min <- pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getattr(self, "feature_range"), 0L))
    .py_it_19 <- pyrt::py_iter(X)
    repeat {
      .py_step_20 <- pyrt::py_iter_step(.py_it_19)
      if (.py_step_20$stopped) break
      row <- .py_step_20$value
      scaled_row <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_builtin("float")(pyrt::py_getitem(row, j))
        scaled <- pyrt::py_add(pyrt::py_mul(pyrt::py_sub(val, pyrt::py_getitem(pyrt::py_getattr(self, "data_min_"), j)), pyrt::py_getitem(pyrt::py_getattr(self, "scale_"), j)), t_min)
        pyrt::py_getattr(scaled_row, "append")(scaled)
      }
      pyrt::py_getattr(out, "append")(scaled_row)
    }
    return(out)
  }
  .py_cdict_10[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "transform")(X))
  }
  .py_cdict_10[["inverse_transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    n_features <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "data_min_"))
    t_min <- pyrt::py_builtin("float")(pyrt::py_getitem(pyrt::py_getattr(self, "feature_range"), 0L))
    .py_it_21 <- pyrt::py_iter(X)
    repeat {
      .py_step_22 <- pyrt::py_iter_step(.py_it_21)
      if (.py_step_22$stopped) break
      row <- .py_step_22$value
      orig_row <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_builtin("float")(pyrt::py_getitem(row, j))
        orig <- pyrt::py_add(pyrt::py_truediv(pyrt::py_sub(val, t_min), pyrt::py_getitem(pyrt::py_getattr(self, "scale_"), j)), pyrt::py_getitem(pyrt::py_getattr(self, "data_min_"), j))
        pyrt::py_getattr(orig_row, "append")(orig)
      }
      pyrt::py_getattr(out, "append")(orig_row)
    }
    return(out)
  }
  .py_cdict_10
})())
RobustScaler <- pyrt::py_class("RobustScaler", bases = list(), dict = (function() {
  .py_cdict_23 <- list()
  .py_cdict_23[["__init__"]] <- function(self) {
    pyrt::py_setattr(self, "center_", pyrt::py_list())
    pyrt::py_setattr(self, "scale_", pyrt::py_list())
    pyrt::py_none()
  }
  .py_cdict_23[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    n_samples <- pyrt::py_builtin("len")(X)
    if (pyrt::py_bool(pyrt::py_eq(n_samples, 0L))) {
      return(self)
    }
    n_features <- pyrt::py_builtin("len")(pyrt::py_getitem(X, 0L))
    centers <- pyrt::py_list()
    scales <- pyrt::py_list()
    for (j in pyrt::py_range_seq(n_features)) {
      col <- pyrt::py_builtin("sorted")((function() {
        .py_comp_24 <- list()
        .py_it_25 <- pyrt::py_iter(X)
        repeat {
          .py_step_26 <- pyrt::py_iter_step(.py_it_25)
          if (.py_step_26$stopped) break
          row <- .py_step_26$value
          .py_comp_24[length(.py_comp_24) + 1L] <- list(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)))
        }
        pyrt::py_list(.py_comp_24)
      })())
      med <- pyrt::py_getitem(col, pyrt::py_floordiv(n_samples, 2L))
      q25 <- pyrt::py_getitem(col, pyrt::py_builtin("int")(pyrt::py_mul(n_samples, 0.25)))
      q75 <- pyrt::py_getitem(col, pyrt::py_builtin("int")(pyrt::py_mul(n_samples, 0.75)))
      iqr <- pyrt::py_sub(q75, q25)
      pyrt::py_getattr(centers, "append")(med)
      pyrt::py_getattr(scales, "append")((if (pyrt::py_bool(pyrt::py_gt(iqr, 1e-12))) iqr else 1.0))
    }
    pyrt::py_setattr(self, "center_", centers)
    pyrt::py_setattr(self, "scale_", scales)
    return(self)
  }
  .py_cdict_23[["transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    n_features <- pyrt::py_builtin("len")(pyrt::py_getattr(self, "center_"))
    .py_it_27 <- pyrt::py_iter(X)
    repeat {
      .py_step_28 <- pyrt::py_iter_step(.py_it_27)
      if (.py_step_28$stopped) break
      row <- .py_step_28$value
      scaled_row <- pyrt::py_list()
      for (j in pyrt::py_range_seq(n_features)) {
        val <- pyrt::py_truediv(pyrt::py_sub(pyrt::py_builtin("float")(pyrt::py_getitem(row, j)), pyrt::py_getitem(pyrt::py_getattr(self, "center_"), j)), pyrt::py_getitem(pyrt::py_getattr(self, "scale_"), j))
        pyrt::py_getattr(scaled_row, "append")(val)
      }
      pyrt::py_getattr(out, "append")(scaled_row)
    }
    return(out)
  }
  .py_cdict_23[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(X, y), "transform")(X))
  }
  .py_cdict_23
})())
Binarizer <- pyrt::py_class("Binarizer", bases = list(), dict = (function() {
  .py_cdict_29 <- list()
  .py_cdict_29[["__init__"]] <- function(self, threshold = 0.0) {
    pyrt::py_setattr(self, "threshold", pyrt::py_builtin("float")(threshold))
    pyrt::py_none()
  }
  .py_cdict_29[["fit"]] <- function(self, X, y = pyrt::py_none()) {
    return(self)
  }
  .py_cdict_29[["transform"]] <- function(self, X) {
    out <- pyrt::py_list()
    .py_it_30 <- pyrt::py_iter(X)
    repeat {
      .py_step_31 <- pyrt::py_iter_step(.py_it_30)
      if (.py_step_31$stopped) break
      row <- .py_step_31$value
      pyrt::py_getattr(out, "append")((function() {
        .py_comp_32 <- list()
        .py_it_33 <- pyrt::py_iter(row)
        repeat {
          .py_step_34 <- pyrt::py_iter_step(.py_it_33)
          if (.py_step_34$stopped) break
          x <- .py_step_34$value
          .py_comp_32[length(.py_comp_32) + 1L] <- list((if (pyrt::py_bool(pyrt::py_gt(pyrt::py_builtin("float")(x), pyrt::py_getattr(self, "threshold")))) 1.0 else 0.0))
        }
        pyrt::py_list(.py_comp_32)
      })())
    }
    return(out)
  }
  .py_cdict_29[["fit_transform"]] <- function(self, X, y = pyrt::py_none()) {
    return(pyrt::py_getattr(self, "transform")(X))
  }
  .py_cdict_29
})())
LabelEncoder <- pyrt::py_class("LabelEncoder", bases = list(), dict = (function() {
  .py_cdict_35 <- list()
  .py_cdict_35[["__init__"]] <- function(self) {
    pyrt::py_setattr(self, "classes_", pyrt::py_list())
    pyrt::py_setattr(self, "_mapping", pyrt::py_dict())
    pyrt::py_none()
  }
  .py_cdict_35[["fit"]] <- function(self, y) {
    unique <- pyrt::py_list()
    .py_it_36 <- pyrt::py_iter(y)
    repeat {
      .py_step_37 <- pyrt::py_iter_step(.py_it_36)
      if (.py_step_37$stopped) break
      label <- .py_step_37$value
      if (pyrt::py_bool((!pyrt::py_in(label, unique)))) {
        pyrt::py_getattr(unique, "append")(label)
      }
    }
    pyrt::py_getattr(unique, "sort")()
    pyrt::py_setattr(self, "classes_", unique)
    pyrt::py_setattr(self, "_mapping", (function() {
      .py_comp_38 <- pyrt::py_dict()
      .py_it_39 <- pyrt::py_iter(pyrt::py_builtin("enumerate")(unique))
      repeat {
        .py_step_40 <- pyrt::py_iter_step(.py_it_39)
        if (.py_step_40$stopped) break
        .py_unp_41 <- pyrt::py_unpack(.py_step_40$value, 2L)
        i <- .py_unp_41[[1L]]
        label <- .py_unp_41[[2L]]
        .py_comp_38$set(label, i)
      }
      .py_comp_38
    })())
    return(self)
  }
  .py_cdict_35[["transform"]] <- function(self, y) {
    return((function() {
      .py_comp_42 <- list()
      .py_it_43 <- pyrt::py_iter(y)
      repeat {
        .py_step_44 <- pyrt::py_iter_step(.py_it_43)
        if (.py_step_44$stopped) break
        label <- .py_step_44$value
        .py_comp_42[length(.py_comp_42) + 1L] <- list(pyrt::py_getitem(pyrt::py_getattr(self, "_mapping"), label))
      }
      pyrt::py_list(.py_comp_42)
    })())
  }
  .py_cdict_35[["fit_transform"]] <- function(self, y) {
    return(pyrt::py_getattr(pyrt::py_getattr(self, "fit")(y), "transform")(y))
  }
  .py_cdict_35[["inverse_transform"]] <- function(self, y) {
    return((function() {
      .py_comp_45 <- list()
      .py_it_46 <- pyrt::py_iter(y)
      repeat {
        .py_step_47 <- pyrt::py_iter_step(.py_it_46)
        if (.py_step_47$stopped) break
        idx <- .py_step_47$value
        .py_comp_45[length(.py_comp_45) + 1L] <- list(pyrt::py_getitem(pyrt::py_getattr(self, "classes_"), pyrt::py_builtin("int")(idx)))
      }
      pyrt::py_list(.py_comp_45)
    })())
  }
  .py_cdict_35
})())
